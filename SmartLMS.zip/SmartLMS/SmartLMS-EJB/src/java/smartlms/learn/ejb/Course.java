/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package smartlms.learn.ejb;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 *
 * @author sfiso
 */
@Entity
@Table(name = "courses")
@NamedQueries({
    @NamedQuery(name = "Course.findByInstructor", 
                query = "SELECT c FROM Course c WHERE c.instructor.id = :instructorId"),
    @NamedQuery(name = "Course.findByCategory", 
                query = "SELECT c FROM Course c WHERE c.category = :category"),
    @NamedQuery(name = "Course.findByLevel", 
                query = "SELECT c FROM Course c WHERE c.level = :level"),
    @NamedQuery(name = "Course.findAllActive", 
                query = "SELECT c FROM Course c WHERE c.active = true")
})
public class Course implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false, length = 200)
    private String title;
    
    @Column(length = 1000)
    private String description;
    
    @ManyToOne
    @JoinColumn(name = "instructor_id")
    private User instructor;
    
    @Column(length = 50)
    private String category;
    
    @Column(length = 20)
    private String level; // BEGINNER, INTERMEDIATE, ADVANCED
    
    @Column(length = 255)
    private String thumbnail;
    
    @Column(name = "price")
    private Double price = 0.0;
    
    @Column(name = "created_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    
    @Column(name = "updated_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;
    
    @Column
    private boolean active = true;
    
    // ===== RELATIONSHIPS =====
    
    // 1. Lessons
    @OneToMany(mappedBy = "course", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Lesson> lessons;
    
    // 2. Assignments
    @OneToMany(mappedBy = "course", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Assignment> assignments;
    
    // 3. Enrollments
    @OneToMany(mappedBy = "course", fetch = FetchType.LAZY)
    private List<Enrollment> enrollments;
    
    // 4. Discussions
    @OneToMany(mappedBy = "course", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Discussion> discussions;
    
    // 5. Quizzes (NEW)
    @OneToMany(mappedBy = "course", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Quiz> quizzes;

    // ===== CONSTRUCTORS =====
    
    public Course() {
        this.createdAt = new Date();
        this.updatedAt = new Date();
    }

    // ===== GETTERS AND SETTERS =====
    
    public Long getId() { 
        return id; 
    }
    
    public void setId(Long id) { 
        this.id = id; 
    }

    public String getTitle() { 
        return title; 
    }
    
    public void setTitle(String title) { 
        this.title = title; 
    }

    public String getDescription() { 
        return description; 
    }
    
    public void setDescription(String description) { 
        this.description = description; 
    }

    public User getInstructor() { 
        return instructor; 
    }
    
    public void setInstructor(User instructor) { 
        this.instructor = instructor; 
    }

    public String getCategory() { 
        return category; 
    }
    
    public void setCategory(String category) { 
        this.category = category; 
    }

    public String getLevel() { 
        return level; 
    }
    
    public void setLevel(String level) { 
        this.level = level; 
    }

    public String getThumbnail() { 
        return thumbnail; 
    }
    
    public void setThumbnail(String thumbnail) { 
        this.thumbnail = thumbnail; 
    }

    public Double getPrice() { 
        return price; 
    }
    
    public void setPrice(Double price) { 
        this.price = price; 
    }

    public Date getCreatedAt() { 
        return createdAt; 
    }
    
    public void setCreatedAt(Date createdAt) { 
        this.createdAt = createdAt; 
    }

    public Date getUpdatedAt() { 
        return updatedAt; 
    }
    
    public void setUpdatedAt(Date updatedAt) { 
        this.updatedAt = updatedAt; 
    }

    public boolean isActive() { 
        return active; 
    }
    
    public void setActive(boolean active) { 
        this.active = active; 
    }

    // ===== RELATIONSHIP GETTERS AND SETTERS =====
    
    // Lessons
    public List<Lesson> getLessons() { 
        return lessons; 
    }
    
    public void setLessons(List<Lesson> lessons) { 
        this.lessons = lessons; 
    }

    // Assignments
    public List<Assignment> getAssignments() { 
        return assignments; 
    }
    
    public void setAssignments(List<Assignment> assignments) { 
        this.assignments = assignments; 
    }

    // Enrollments
    public List<Enrollment> getEnrollments() { 
        return enrollments; 
    }
    
    public void setEnrollments(List<Enrollment> enrollments) { 
        this.enrollments = enrollments; 
    }

    // Discussions
    public List<Discussion> getDiscussions() { 
        return discussions; 
    }
    
    public void setDiscussions(List<Discussion> discussions) { 
        this.discussions = discussions; 
    }

    // Quizzes (NEW)
    public List<Quiz> getQuizzes() { 
        return quizzes; 
    }
    
    public void setQuizzes(List<Quiz> quizzes) { 
        this.quizzes = quizzes; 
    }

    // ===== STANDARD METHODS =====
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Course)) {
            return false;
        }
        Course other = (Course) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Course[ id=" + id + ", title=" + title + " ]";
    }
}