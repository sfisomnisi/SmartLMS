/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package smartlms.learn.ejb;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "quiz_attempts")
@NamedQueries({
    @NamedQuery(name = "QuizAttempt.findByStudent", 
                query = "SELECT q FROM QuizAttempt q WHERE q.student.id = :studentId"),
    @NamedQuery(name = "QuizAttempt.findByStudentAndQuiz", 
                query = "SELECT q FROM QuizAttempt q WHERE q.student.id = :studentId AND q.quiz.id = :quizId")
})
public class QuizAttempt implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne
    @JoinColumn(name = "student_id")
    private User student;
    
    @ManyToOne
    @JoinColumn(name = "quiz_id")
    private Quiz quiz;
    
    @Column
    private Integer score = 0;
    
    @Column
    private Boolean passed = false;
    
    @Column(name = "attempted_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date attemptedAt;

    public QuizAttempt() {
        this.attemptedAt = new Date();
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public User getStudent() { return student; }
    public void setStudent(User student) { this.student = student; }

    public Quiz getQuiz() { return quiz; }
    public void setQuiz(Quiz quiz) { this.quiz = quiz; }

    public Integer getScore() { return score; }
    public void setScore(Integer score) { this.score = score; }

    public Boolean getPassed() { return passed; }
    public void setPassed(Boolean passed) { this.passed = passed; }

    public Date getAttemptedAt() { return attemptedAt; }
    public void setAttemptedAt(Date attemptedAt) { this.attemptedAt = attemptedAt; }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof QuizAttempt)) {
            return false;
        }
        QuizAttempt other = (QuizAttempt) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "QuizAttempt[ id=" + id + ", student=" + student.getEmail() + ", quiz=" + quiz.getTitle() + " ]";
    }
}