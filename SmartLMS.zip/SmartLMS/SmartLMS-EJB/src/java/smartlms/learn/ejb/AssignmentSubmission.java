/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package smartlms.learn.ejb;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "assignment_submissions")
@NamedQueries({
    @NamedQuery(name = "AssignmentSubmission.findByAssignment", 
                query = "SELECT a FROM AssignmentSubmission a WHERE a.assignment.id = :assignmentId"),
    @NamedQuery(name = "AssignmentSubmission.findByStudent", 
                query = "SELECT a FROM AssignmentSubmission a WHERE a.student.id = :studentId"),
    @NamedQuery(name = "AssignmentSubmission.findByAssignmentAndStudent", 
                query = "SELECT a FROM AssignmentSubmission a WHERE a.assignment.id = :assignmentId AND a.student.id = :studentId")
})
public class AssignmentSubmission implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne
    @JoinColumn(name = "assignment_id")
    private Assignment assignment;
    
    @ManyToOne
    @JoinColumn(name = "student_id")
    private User student;
    
    @Column(name = "file_url", length = 500)
    private String fileUrl;
    
    @Column(name = "file_name", length = 255)
    private String fileName;
    
    @Column(name = "submitted_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date submittedAt;
    
    @Column
    private Integer grade = 0;
    
    @Column(length = 500)
    private String feedback;
    
    @Column(name = "graded_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date gradedAt;
    
    @Column(name = "graded_by")
    private Long gradedBy;
    
    @Column(length = 20)
    private String status = "PENDING"; // PENDING, GRADED, RETURNED

    public AssignmentSubmission() {
        this.submittedAt = new Date();
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Assignment getAssignment() { return assignment; }
    public void setAssignment(Assignment assignment) { this.assignment = assignment; }

    public User getStudent() { return student; }
    public void setStudent(User student) { this.student = student; }

    public String getFileUrl() { return fileUrl; }
    public void setFileUrl(String fileUrl) { this.fileUrl = fileUrl; }

    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }

    public Date getSubmittedAt() { return submittedAt; }
    public void setSubmittedAt(Date submittedAt) { this.submittedAt = submittedAt; }

    public Integer getGrade() { return grade; }
    public void setGrade(Integer grade) { 
        this.grade = grade;
        if (grade != null && grade > 0) {
            this.status = "GRADED";
            this.gradedAt = new Date();
        }
    }

    public String getFeedback() { return feedback; }
    public void setFeedback(String feedback) { this.feedback = feedback; }

    public Date getGradedAt() { return gradedAt; }
    public void setGradedAt(Date gradedAt) { this.gradedAt = gradedAt; }

    public Long getGradedBy() { return gradedBy; }
    public void setGradedBy(Long gradedBy) { this.gradedBy = gradedBy; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof AssignmentSubmission)) {
            return false;
        }
        AssignmentSubmission other = (AssignmentSubmission) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "AssignmentSubmission[ id=" + id + ", student=" + student.getEmail() + ", assignment=" + assignment.getTitle() + " ]";
    }
}