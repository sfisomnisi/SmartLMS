/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package smartlms.learn.ejb;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author sfiso
 */
@Entity
@Table(name = "submissions")
@NamedQueries({
    @NamedQuery(name = "Submission.findByAssignment", 
                query = "SELECT s FROM Submission s WHERE s.assignment.id = :assignmentId"),
    @NamedQuery(name = "Submission.findByStudent", 
                query = "SELECT s FROM Submission s WHERE s.student.id = :studentId"),
    @NamedQuery(name = "Submission.findByAssignmentAndStudent", 
                query = "SELECT s FROM Submission s WHERE s.assignment.id = :assignmentId AND s.student.id = :studentId"),
    @NamedQuery(name = "Submission.findPending", 
                query = "SELECT s FROM Submission s WHERE s.status = 'PENDING'")
})
public class Submission implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne
    @JoinColumn(name = "assignment_id")
    private Assignment assignment;
    
    @ManyToOne
    @JoinColumn(name = "student_id")
    private User student;
    
    @Column(name = "submission_text", length = 1000)
    private String submissionText;
    
    @Column(name = "file_url", length = 255)
    private String fileUrl;
    
    @Column(name = "submitted_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date submittedAt;
    
    @Column(length = 20)
    private String status = "PENDING"; // PENDING, GRADED, RETURNED
    
    @Column(name = "grade")
    private Integer grade;
    
    @Column(name = "feedback", length = 500)
    private String feedback;
    
    @Column(name = "graded_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date gradedAt;
    
    @Column(name = "graded_by")
    private Long gradedBy;

    // Constructors
    public Submission() {
        this.submittedAt = new Date();
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Assignment getAssignment() { return assignment; }
    public void setAssignment(Assignment assignment) { this.assignment = assignment; }

    public User getStudent() { return student; }
    public void setStudent(User student) { this.student = student; }

    public String getSubmissionText() { return submissionText; }
    public void setSubmissionText(String submissionText) { this.submissionText = submissionText; }

    public String getFileUrl() { return fileUrl; }
    public void setFileUrl(String fileUrl) { this.fileUrl = fileUrl; }

    public Date getSubmittedAt() { return submittedAt; }
    public void setSubmittedAt(Date submittedAt) { this.submittedAt = submittedAt; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public Integer getGrade() { return grade; }
    public void setGrade(Integer grade) { 
        this.grade = grade;
        if (grade != null) {
            this.status = "GRADED";
            this.gradedAt = new Date();
        }
    }

    public String getFeedback() { return feedback; }
    public void setFeedback(String feedback) { this.feedback = feedback; }

    public Date getGradedAt() { return gradedAt; }
    public void setGradedAt(Date gradedAt) { this.gradedAt = gradedAt; }

    public Long getGradedBy() { return gradedBy; }
    public void setGradedBy(Long gradedBy) { this.gradedBy = gradedBy; }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Submission)) {
            return false;
        }
        Submission other = (Submission) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Submission[ id=" + id + ", student=" + student.getEmail() + ", assignment=" + assignment.getTitle() + " ]";
    }
}