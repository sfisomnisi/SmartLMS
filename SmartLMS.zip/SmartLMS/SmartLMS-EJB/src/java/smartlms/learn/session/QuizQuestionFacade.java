/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package smartlms.learn.session;

import smartlms.learn.ejb.QuizQuestion;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import java.util.List;

@Stateless
public class QuizQuestionFacade extends AbstractFacade<QuizQuestion> implements QuizQuestionFacadeLocal {

    @PersistenceContext(unitName = "SmartLMS-EJBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public QuizQuestionFacade() {
        super(QuizQuestion.class);
    }

    @Override
    public List<QuizQuestion> findByQuiz(Long quizId) {
        TypedQuery<QuizQuestion> query = em.createNamedQuery("QuizQuestion.findByQuiz", QuizQuestion.class);
        query.setParameter("quizId", quizId);
        return query.getResultList();
    }

    @Override
    public int countByQuiz(Long quizId) {
        TypedQuery<Long> query = em.createQuery(
            "SELECT COUNT(q) FROM QuizQuestion q WHERE q.quiz.id = :quizId", Long.class);
        query.setParameter("quizId", quizId);
        return query.getSingleResult().intValue();
    }
}