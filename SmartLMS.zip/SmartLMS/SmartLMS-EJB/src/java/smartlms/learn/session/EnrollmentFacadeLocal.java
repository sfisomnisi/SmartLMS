/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package smartlms.learn.session;

import smartlms.learn.ejb.Enrollment;
import jakarta.ejb.Local;
import java.util.List;

@Local
public interface EnrollmentFacadeLocal {

    void create(Enrollment enrollment);
    void edit(Enrollment enrollment);
    void remove(Enrollment enrollment);
    Enrollment find(Object id);
    List<Enrollment> findAll();
    List<Enrollment> findRange(int[] range);
    int count();
    
    // Custom business methods
    List<Enrollment> findByStudent(Long studentId);
    List<Enrollment> findByCourse(Long courseId);
    Enrollment findByStudentAndCourse(Long studentId, Long courseId);
    List<Enrollment> findCompleted();
    void updateProgress(Long enrollmentId, Integer progress);
    void markCompleted(Long enrollmentId);
    boolean isEnrolled(Long studentId, Long courseId);
}