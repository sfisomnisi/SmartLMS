/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package smartlms.learn.session;

import smartlms.learn.ejb.QuizAttempt;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import java.util.List;

@Stateless
public class QuizAttemptFacade extends AbstractFacade<QuizAttempt> implements QuizAttemptFacadeLocal {

    @PersistenceContext(unitName = "SmartLMS-EJBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public QuizAttemptFacade() {
        super(QuizAttempt.class);
    }

    @Override
    public List<QuizAttempt> findByStudent(Long studentId) {
        TypedQuery<QuizAttempt> query = em.createNamedQuery("QuizAttempt.findByStudent", QuizAttempt.class);
        query.setParameter("studentId", studentId);
        return query.getResultList();
    }

    @Override
    public QuizAttempt findByStudentAndQuiz(Long studentId, Long quizId) {
        try {
            TypedQuery<QuizAttempt> query = em.createNamedQuery("QuizAttempt.findByStudentAndQuiz", QuizAttempt.class);
            query.setParameter("studentId", studentId);
            query.setParameter("quizId", quizId);
            return query.getSingleResult();
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public List<QuizAttempt> findPassedByStudent(Long studentId) {
        TypedQuery<QuizAttempt> query = em.createQuery(
            "SELECT q FROM QuizAttempt q WHERE q.student.id = :studentId AND q.passed = true", 
            QuizAttempt.class);
        query.setParameter("studentId", studentId);
        return query.getResultList();
    }

    @Override
    public int getAverageScoreByStudent(Long studentId) {
        try {
            TypedQuery<Double> query = em.createQuery(
                "SELECT AVG(q.score) FROM QuizAttempt q WHERE q.student.id = :studentId", 
                Double.class);
            query.setParameter("studentId", studentId);
            Double avg = query.getSingleResult();
            return avg != null ? avg.intValue() : 0;
        } catch (Exception e) {
            return 0;
        }
    }
}