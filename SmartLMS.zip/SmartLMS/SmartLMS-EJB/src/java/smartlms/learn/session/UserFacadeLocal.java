/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package smartlms.learn.session;

import smartlms.learn.ejb.User;
import jakarta.ejb.Local;
import java.util.List;

/**
 *
 * @author sfiso
 */
@Local
public interface UserFacadeLocal {

    void create(User user);

    void edit(User user);

    void remove(User user);

    User find(Object id);

    List<User> findAll();

    List<User> findRange(int[] range);

    int count();
    
    // Custom business methods
    User findByEmail(String email);
    
    User login(String email, String password);
    
    List<User> findByRole(String role);
    
    List<User> findAllActive();
}
