/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package smartlms.learn.session;

import smartlms.learn.ejb.AssignmentSubmission;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import java.util.Date;
import java.util.List;

@Stateless
public class AssignmentSubmissionFacade extends AbstractFacade<AssignmentSubmission> implements AssignmentSubmissionFacadeLocal {

    @PersistenceContext(unitName = "SmartLMS-EJBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public AssignmentSubmissionFacade() {
        super(AssignmentSubmission.class);
    }

    @Override
    public List<AssignmentSubmission> findByAssignment(Long assignmentId) {
        TypedQuery<AssignmentSubmission> query = em.createNamedQuery("AssignmentSubmission.findByAssignment", AssignmentSubmission.class);
        query.setParameter("assignmentId", assignmentId);
        return query.getResultList();
    }

    @Override
    public List<AssignmentSubmission> findByStudent(Long studentId) {
        TypedQuery<AssignmentSubmission> query = em.createNamedQuery("AssignmentSubmission.findByStudent", AssignmentSubmission.class);
        query.setParameter("studentId", studentId);
        return query.getResultList();
    }

    @Override
    public AssignmentSubmission findByAssignmentAndStudent(Long assignmentId, Long studentId) {
        try {
            TypedQuery<AssignmentSubmission> query = em.createNamedQuery("AssignmentSubmission.findByAssignmentAndStudent", AssignmentSubmission.class);
            query.setParameter("assignmentId", assignmentId);
            query.setParameter("studentId", studentId);
            return query.getSingleResult();
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public List<AssignmentSubmission> findPending() {
        TypedQuery<AssignmentSubmission> query = em.createQuery(
            "SELECT a FROM AssignmentSubmission a WHERE a.status = 'PENDING'", 
            AssignmentSubmission.class);
        return query.getResultList();
    }

    @Override
    public List<AssignmentSubmission> findGraded() {
        TypedQuery<AssignmentSubmission> query = em.createQuery(
            "SELECT a FROM AssignmentSubmission a WHERE a.status = 'GRADED'", 
            AssignmentSubmission.class);
        return query.getResultList();
    }

    @Override
    public void gradeSubmission(Long submissionId, Integer grade, String feedback, Long gradedBy) {
        AssignmentSubmission submission = find(submissionId);
        if (submission != null) {
            submission.setGrade(grade);
            submission.setFeedback(feedback);
            submission.setGradedBy(gradedBy);
            submission.setGradedAt(new Date());
            submission.setStatus("GRADED");
            edit(submission);
        }
    }
}