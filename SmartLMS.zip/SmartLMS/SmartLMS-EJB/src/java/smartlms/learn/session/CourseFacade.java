/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package smartlms.learn.session;

import smartlms.learn.ejb.Course;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import java.util.List;

@Stateless
public class CourseFacade extends AbstractFacade<Course> implements CourseFacadeLocal {

    @PersistenceContext(unitName = "SmartLMS-EJBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public CourseFacade() {
        super(Course.class);
    }

    @Override
    public List<Course> findByInstructor(Long instructorId) {
        TypedQuery<Course> query = em.createNamedQuery("Course.findByInstructor", Course.class);
        query.setParameter("instructorId", instructorId);
        return query.getResultList();
    }

    @Override
    public List<Course> findByCategory(String category) {
        TypedQuery<Course> query = em.createNamedQuery("Course.findByCategory", Course.class);
        query.setParameter("category", category);
        return query.getResultList();
    }

    @Override
    public List<Course> findByLevel(String level) {
        TypedQuery<Course> query = em.createNamedQuery("Course.findByLevel", Course.class);
        query.setParameter("level", level);
        return query.getResultList();
    }

    @Override
    public List<Course> findAllActive() {
        TypedQuery<Course> query = em.createNamedQuery("Course.findAllActive", Course.class);
        return query.getResultList();
    }
    
    // Additional method to get course with all relationships
    public Course findWithDetails(Long courseId) {
        try {
            TypedQuery<Course> query = em.createQuery(
                "SELECT c FROM Course c " +
                "LEFT JOIN FETCH c.lessons " +
                "LEFT JOIN FETCH c.assignments " +
                "LEFT JOIN FETCH c.quizzes " +
                "WHERE c.id = :courseId", 
                Course.class);
            query.setParameter("courseId", courseId);
            return query.getSingleResult();
        } catch (Exception e) {
            return null;
        }
    }
}