/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package smartlms.learn.session;

import smartlms.learn.ejb.DiscussionReply;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import java.util.List;

/**
 *
 * @author sfiso
 */
@Stateless
public class DiscussionReplyFacade extends AbstractFacade<DiscussionReply> implements DiscussionReplyFacadeLocal {

    @PersistenceContext(unitName = "SmartLMS-EJBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public DiscussionReplyFacade() {
        super(DiscussionReply.class);
    }

    @Override
    public List<DiscussionReply> findByDiscussion(Long discussionId) {
        TypedQuery<DiscussionReply> query = em.createQuery(
            "SELECT r FROM DiscussionReply r WHERE r.discussion.id = :discussionId ORDER BY r.createdAt", 
            DiscussionReply.class);
        query.setParameter("discussionId", discussionId);
        return query.getResultList();
    }

    @Override
    public List<DiscussionReply> findByAuthor(Long authorId) {
        TypedQuery<DiscussionReply> query = em.createQuery(
            "SELECT r FROM DiscussionReply r WHERE r.author.id = :authorId", 
            DiscussionReply.class);
        query.setParameter("authorId", authorId);
        return query.getResultList();
    }
}