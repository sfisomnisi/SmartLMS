/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package smartlms.learn.session;

import smartlms.learn.ejb.Quiz;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import java.util.List;

@Stateless
public class QuizFacade extends AbstractFacade<Quiz> implements QuizFacadeLocal {

    @PersistenceContext(unitName = "SmartLMS-EJBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public QuizFacade() {
        super(Quiz.class);
    }

    @Override
    public List<Quiz> findByCourse(Long courseId) {
        TypedQuery<Quiz> query = em.createNamedQuery("Quiz.findByCourse", Quiz.class);
        query.setParameter("courseId", courseId);
        return query.getResultList();
    }

    @Override
    public Quiz findByCourseAndTitle(Long courseId, String title) {
        try {
            TypedQuery<Quiz> query = em.createQuery(
                "SELECT q FROM Quiz q WHERE q.course.id = :courseId AND q.title = :title", 
                Quiz.class);
            query.setParameter("courseId", courseId);
            query.setParameter("title", title);
            return query.getSingleResult();
        } catch (Exception e) {
            return null;
        }
    }
}