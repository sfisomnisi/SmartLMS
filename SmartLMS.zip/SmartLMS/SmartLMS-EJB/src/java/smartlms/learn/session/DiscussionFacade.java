/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package smartlms.learn.session;

import smartlms.learn.ejb.Discussion;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import java.util.List;

/**
 *
 * @author sfiso
 */
@Stateless
public class DiscussionFacade extends AbstractFacade<Discussion> implements DiscussionFacadeLocal {

    @PersistenceContext(unitName = "SmartLMS-EJBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public DiscussionFacade() {
        super(Discussion.class);
    }

    @Override
    public List<Discussion> findByCourse(Long courseId) {
        TypedQuery<Discussion> query = em.createNamedQuery("Discussion.findByCourse", Discussion.class);
        query.setParameter("courseId", courseId);
        return query.getResultList();
    }

    @Override
    public List<Discussion> findByUser(Long authorId) {
        TypedQuery<Discussion> query = em.createNamedQuery("Discussion.findByUser", Discussion.class);
        query.setParameter("authorId", authorId);
        return query.getResultList();
    }

    @Override
    public List<Discussion> findAnnouncements(Long courseId) {
        TypedQuery<Discussion> query = em.createQuery(
            "SELECT d FROM Discussion d WHERE d.course.id = :courseId AND d.announcement = true", 
            Discussion.class);
        query.setParameter("courseId", courseId);
        return query.getResultList();
    }
}