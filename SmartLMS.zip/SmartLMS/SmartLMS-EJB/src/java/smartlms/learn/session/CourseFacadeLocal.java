/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package smartlms.learn.session;

import smartlms.learn.ejb.Course;
import jakarta.ejb.Local;
import java.util.List;

/**
 *
 * @author sfiso
 */
@Local
public interface CourseFacadeLocal {

    void create(Course course);

    void edit(Course course);

    void remove(Course course);

    Course find(Object id);

    List<Course> findAll();

    List<Course> findRange(int[] range);

    int count();
    
    // Custom business methods
    List<Course> findByInstructor(Long instructorId);
    
    List<Course> findByCategory(String category);
    
    List<Course> findByLevel(String level);
    
    List<Course> findAllActive();
}