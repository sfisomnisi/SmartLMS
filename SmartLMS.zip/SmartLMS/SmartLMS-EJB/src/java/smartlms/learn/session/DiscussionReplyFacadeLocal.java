/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package smartlms.learn.session;

import smartlms.learn.ejb.DiscussionReply;
import jakarta.ejb.Local;
import java.util.List;

/**
 *
 * @author sfiso
 */
@Local
public interface DiscussionReplyFacadeLocal {

    void create(DiscussionReply reply);

    void edit(DiscussionReply reply);

    void remove(DiscussionReply reply);

    DiscussionReply find(Object id);

    List<DiscussionReply> findAll();

    List<DiscussionReply> findRange(int[] range);

    int count();
    
    // Custom business methods
    List<DiscussionReply> findByDiscussion(Long discussionId);
    
    List<DiscussionReply> findByAuthor(Long authorId);
}