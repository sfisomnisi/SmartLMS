/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package smartlms.learn.session;

import smartlms.learn.ejb.QuizQuestion;
import jakarta.ejb.Local;
import java.util.List;

@Local
public interface QuizQuestionFacadeLocal {

    void create(QuizQuestion question);
    void edit(QuizQuestion question);
    void remove(QuizQuestion question);
    QuizQuestion find(Object id);
    List<QuizQuestion> findAll();
    List<QuizQuestion> findRange(int[] range);
    int count();
    
    // Custom methods
    List<QuizQuestion> findByQuiz(Long quizId);
    int countByQuiz(Long quizId);
}