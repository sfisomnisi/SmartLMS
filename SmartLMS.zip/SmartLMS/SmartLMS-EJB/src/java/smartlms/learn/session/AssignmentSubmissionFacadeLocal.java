/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package smartlms.learn.session;

import smartlms.learn.ejb.AssignmentSubmission;
import jakarta.ejb.Local;
import java.util.List;

@Local
public interface AssignmentSubmissionFacadeLocal {

    void create(AssignmentSubmission submission);
    void edit(AssignmentSubmission submission);
    void remove(AssignmentSubmission submission);
    AssignmentSubmission find(Object id);
    List<AssignmentSubmission> findAll();
    List<AssignmentSubmission> findRange(int[] range);
    int count();
    
    // Custom methods
    List<AssignmentSubmission> findByAssignment(Long assignmentId);
    List<AssignmentSubmission> findByStudent(Long studentId);
    AssignmentSubmission findByAssignmentAndStudent(Long assignmentId, Long studentId);
    List<AssignmentSubmission> findPending();
    List<AssignmentSubmission> findGraded();
    void gradeSubmission(Long submissionId, Integer grade, String feedback, Long gradedBy);
}