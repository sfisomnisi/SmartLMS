/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package smartlms.learn.session;

import smartlms.learn.ejb.Lesson;
import jakarta.ejb.Local;
import java.util.List;

/**
 *
 * @author sfiso
 */
@Local
public interface LessonFacadeLocal {

    void create(Lesson lesson);

    void edit(Lesson lesson);

    void remove(Lesson lesson);

    Lesson find(Object id);

    List<Lesson> findAll();

    List<Lesson> findRange(int[] range);

    int count();
    
    // Custom business methods
    List<Lesson> findByCourse(Long courseId);
    
    List<Lesson> findByCourseAndOrder(Long courseId, Integer orderNumber);
}