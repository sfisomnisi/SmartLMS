package smartlms.learn.session;

import smartlms.learn.ejb.Submission;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import java.util.Date;
import java.util.List;

@Stateless
public class SubmissionFacade extends AbstractFacade<Submission> implements SubmissionFacadeLocal {

    @PersistenceContext(unitName = "SmartLMS-EJBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SubmissionFacade() {
        super(Submission.class);
    }

    @Override
    public List<Submission> findByAssignment(Long assignmentId) {
        TypedQuery<Submission> query = em.createNamedQuery("Submission.findByAssignment", Submission.class);
        query.setParameter("assignmentId", assignmentId);
        return query.getResultList();
    }

    @Override
    public List<Submission> findByStudent(Long studentId) {
        TypedQuery<Submission> query = em.createNamedQuery("Submission.findByStudent", Submission.class);
        query.setParameter("studentId", studentId);
        return query.getResultList();
    }

    @Override
    public Submission findByAssignmentAndStudent(Long assignmentId, Long studentId) {
        try {
            TypedQuery<Submission> query = em.createNamedQuery("Submission.findByAssignmentAndStudent", Submission.class);
            query.setParameter("assignmentId", assignmentId);
            query.setParameter("studentId", studentId);
            return query.getSingleResult();
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public List<Submission> findPending() {
        TypedQuery<Submission> query = em.createNamedQuery("Submission.findPending", Submission.class);
        return query.getResultList();
    }

    // ⬇️ ADD THIS METHOD ⬇️
    @Override
    public void gradeSubmission(Long submissionId, Integer grade, String feedback, Long gradedBy) {
        Submission submission = find(submissionId);
        if (submission != null) {
            submission.setGrade(grade);
            submission.setFeedback(feedback);
            submission.setGradedBy(gradedBy);
            submission.setGradedAt(new Date());
            submission.setStatus("GRADED");
            edit(submission);
        }
    }
}