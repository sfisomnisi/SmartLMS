/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package smartlms.learn.session;

import smartlms.learn.ejb.Quiz;
import jakarta.ejb.Local;
import java.util.List;

@Local
public interface QuizFacadeLocal {

    void create(Quiz quiz);
    void edit(Quiz quiz);
    void remove(Quiz quiz);
    Quiz find(Object id);
    List<Quiz> findAll();
    List<Quiz> findRange(int[] range);
    int count();
    
    // Custom methods
    List<Quiz> findByCourse(Long courseId);
    Quiz findByCourseAndTitle(Long courseId, String title);
}