/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package smartlms.learn.session;

import smartlms.learn.ejb.Lesson;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import java.util.List;

/**
 *
 * @author sfiso
 */
@Stateless
public class LessonFacade extends AbstractFacade<Lesson> implements LessonFacadeLocal {

    @PersistenceContext(unitName = "SmartLMS-EJBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public LessonFacade() {
        super(Lesson.class);
    }

    @Override
    public List<Lesson> findByCourse(Long courseId) {
        TypedQuery<Lesson> query = em.createNamedQuery("Lesson.findByCourse", Lesson.class);
        query.setParameter("courseId", courseId);
        return query.getResultList();
    }

    @Override
    public List<Lesson> findByCourseAndOrder(Long courseId, Integer orderNumber) {
        TypedQuery<Lesson> query = em.createNamedQuery("Lesson.findByCourseAndOrder", Lesson.class);
        query.setParameter("courseId", courseId);
        query.setParameter("orderNumber", orderNumber);
        return query.getResultList();
    }
}