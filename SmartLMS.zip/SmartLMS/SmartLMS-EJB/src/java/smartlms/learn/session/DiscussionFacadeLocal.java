/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package smartlms.learn.session;

import smartlms.learn.ejb.Discussion;
import jakarta.ejb.Local;
import java.util.List;

/**
 *
 * @author sfiso
 */
@Local
public interface DiscussionFacadeLocal {

    void create(Discussion discussion);

    void edit(Discussion discussion);

    void remove(Discussion discussion);

    Discussion find(Object id);

    List<Discussion> findAll();

    List<Discussion> findRange(int[] range);

    int count();
    
    // Custom business methods
    List<Discussion> findByCourse(Long courseId);
    
    List<Discussion> findByUser(Long authorId);
    
    List<Discussion> findAnnouncements(Long courseId);
}