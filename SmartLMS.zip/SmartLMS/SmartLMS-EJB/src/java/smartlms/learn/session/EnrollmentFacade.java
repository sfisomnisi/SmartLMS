/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package smartlms.learn.session;

import smartlms.learn.ejb.Enrollment;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import java.util.Date;
import java.util.List;

@Stateless
public class EnrollmentFacade extends AbstractFacade<Enrollment> implements EnrollmentFacadeLocal {

    @PersistenceContext(unitName = "SmartLMS-EJBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public EnrollmentFacade() {
        super(Enrollment.class);
    }

    @Override
    public List<Enrollment> findByStudent(Long studentId) {
        TypedQuery<Enrollment> query = em.createNamedQuery("Enrollment.findByStudent", Enrollment.class);
        query.setParameter("studentId", studentId);
        return query.getResultList();
    }

    @Override
    public List<Enrollment> findByCourse(Long courseId) {
        TypedQuery<Enrollment> query = em.createNamedQuery("Enrollment.findByCourse", Enrollment.class);
        query.setParameter("courseId", courseId);
        return query.getResultList();
    }

    @Override
    public Enrollment findByStudentAndCourse(Long studentId, Long courseId) {
        try {
            TypedQuery<Enrollment> query = em.createNamedQuery("Enrollment.findByStudentAndCourse", Enrollment.class);
            query.setParameter("studentId", studentId);
            query.setParameter("courseId", courseId);
            return query.getSingleResult();
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public List<Enrollment> findCompleted() {
        TypedQuery<Enrollment> query = em.createNamedQuery("Enrollment.findCompleted", Enrollment.class);
        return query.getResultList();
    }

    @Override
    public void updateProgress(Long enrollmentId, Integer progress) {
        Enrollment enrollment = find(enrollmentId);
        if (enrollment != null) {
            enrollment.setProgress(progress);
            enrollment.setLastAccessed(new Date());
            edit(enrollment);
        }
    }

    @Override
    public void markCompleted(Long enrollmentId) {
        Enrollment enrollment = find(enrollmentId);
        if (enrollment != null) {
            enrollment.setCompleted(true);
            enrollment.setCompletedAt(new Date());
            enrollment.setProgress(100);
            edit(enrollment);
        }
    }

    @Override
    public boolean isEnrolled(Long studentId, Long courseId) {
        return findByStudentAndCourse(studentId, courseId) != null;
    }
}