/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package smartlms.learn.session;

import smartlms.learn.ejb.Assignment;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import java.util.Date;
import java.util.List;

/**
 *
 * @author sfiso
 */
@Stateless
public class AssignmentFacade extends AbstractFacade<Assignment> implements AssignmentFacadeLocal {

    @PersistenceContext(unitName = "SmartLMS-EJBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public AssignmentFacade() {
        super(Assignment.class);
    }

    @Override
    public List<Assignment> findByCourse(Long courseId) {
        TypedQuery<Assignment> query = em.createNamedQuery("Assignment.findByCourse", Assignment.class);
        query.setParameter("courseId", courseId);
        return query.getResultList();
    }

    @Override
    public List<Assignment> findByCourseAndDueDate(Long courseId, Date date) {
        TypedQuery<Assignment> query = em.createNamedQuery("Assignment.findByCourseAndDueDate", Assignment.class);
        query.setParameter("courseId", courseId);
        query.setParameter("date", date);
        return query.getResultList();
    }

    @Override
    public List<Assignment> findAllActive() {
        TypedQuery<Assignment> query = em.createQuery(
            "SELECT a FROM Assignment a WHERE a.active = true", Assignment.class);
        return query.getResultList();
    }
}