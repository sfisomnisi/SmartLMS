/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package smartlms.learn.session;

import smartlms.learn.ejb.Assignment;
import jakarta.ejb.Local;
import java.util.List;
import java.util.Date;

/**
 *
 * @author sfiso
 */
@Local
public interface AssignmentFacadeLocal {

    void create(Assignment assignment);

    void edit(Assignment assignment);

    void remove(Assignment assignment);

    Assignment find(Object id);

    List<Assignment> findAll();

    List<Assignment> findRange(int[] range);

    int count();
    
    // Custom business methods
    List<Assignment> findByCourse(Long courseId);
    
    List<Assignment> findByCourseAndDueDate(Long courseId, Date date);
    
    List<Assignment> findAllActive();
}