/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package smartlms.learn.session;

import smartlms.learn.ejb.QuizAttempt;
import jakarta.ejb.Local;
import java.util.List;

@Local
public interface QuizAttemptFacadeLocal {

    void create(QuizAttempt attempt);
    void edit(QuizAttempt attempt);
    void remove(QuizAttempt attempt);
    QuizAttempt find(Object id);
    List<QuizAttempt> findAll();
    List<QuizAttempt> findRange(int[] range);
    int count();
    
    // Custom methods
    List<QuizAttempt> findByStudent(Long studentId);
    QuizAttempt findByStudentAndQuiz(Long studentId, Long quizId);
    List<QuizAttempt> findPassedByStudent(Long studentId);
    int getAverageScoreByStudent(Long studentId);
}