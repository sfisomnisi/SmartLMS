package smartlms.learn.session;

import smartlms.learn.ejb.Submission;
import jakarta.ejb.Local;
import java.util.List;

@Local
public interface SubmissionFacadeLocal {

    void create(Submission submission);
    void edit(Submission submission);
    void remove(Submission submission);
    Submission find(Object id);
    List<Submission> findAll();
    List<Submission> findRange(int[] range);
    int count();
    
    // Custom business methods
    List<Submission> findByAssignment(Long assignmentId);
    List<Submission> findByStudent(Long studentId);
    Submission findByAssignmentAndStudent(Long assignmentId, Long studentId);
    List<Submission> findPending();
    
    // ⬇️ ADD THIS METHOD ⬇️
    void gradeSubmission(Long submissionId, Integer grade, String feedback, Long gradedBy);
}