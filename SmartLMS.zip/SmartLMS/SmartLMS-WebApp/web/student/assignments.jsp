<%@ page contentType="text/html" pageEncoding="UTF-8"%>
<%@ page import="java.util.*, smartlms.learn.ejb.*" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Smart LMS - Assignments</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body style="background-image: url('${pageContext.request.contextPath}/images/backgrounds/dashboard-bg.jpg'); background-size: cover; background-position: center;">

    <%
        HttpSession userSession = request.getSession(false);
        User user = (User) userSession.getAttribute("user");
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/public/login.jsp");
            return;
        }
    %>

    <div class="dashboard-container">
        <div class="sidebar">
            <div class="sidebar-logo">
                <img src="${pageContext.request.contextPath}/images/logo/logo-white.png" alt="Smart LMS" width="80">
                <h3 style="color:white;">Smart LMS</h3>
            </div>
            <nav class="sidebar-menu">
                <a href="${pageContext.request.contextPath}/student/dashboard.jsp"><i class="fas fa-home"></i> Dashboard</a>
                <a href="${pageContext.request.contextPath}/enrollments?action=my-courses"><i class="fas fa-book"></i> My Courses</a>
                <a href="${pageContext.request.contextPath}/student/assignments.jsp" class="active"><i class="fas fa-tasks"></i> Assignments</a>
                <a href="${pageContext.request.contextPath}/student/grades.jsp"><i class="fas fa-grade"></i> Grades</a>
                <a href="${pageContext.request.contextPath}/student/discussions.jsp"><i class="fas fa-users"></i> Discussions</a>
                <a href="${pageContext.request.contextPath}/student/profile.jsp"><i class="fas fa-user"></i> Profile</a>
                <a href="${pageContext.request.contextPath}/logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </nav>
        </div>
        
        <div class="main-content">
            <div class="dashboard-header">
                <h2 style="color:white;"><i class="fas fa-tasks" style="color:#4a90d9;"></i> My Assignments</h2>
                <div class="user-info">
                    <img src="${pageContext.request.contextPath}/images/avatars/student-avatar.png" alt="Avatar" width="40" class="avatar">
                    <span style="color:white;"><%= user.getFullName() %></span>
                </div>
            </div>

            <div class="assignments-list" style="margin-top:20px;">
                <!-- Pending Assignments -->
                <div style="background:rgba(255,255,255,0.95);padding:20px;border-radius:15px;margin-bottom:20px;box-shadow:0 5px 20px rgba(0,0,0,0.1);">
                    <h3 style="color:#f39c12;margin-bottom:15px;"><i class="fas fa-clock"></i> Pending Assignments</h3>
                    <div class="assignment-item" style="padding:15px;border-bottom:1px solid #eee;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;">
                        <div>
                            <h4>Web Project</h4>
                            <p style="color:#666;font-size:0.9rem;">Due: 2 days</p>
                        </div>
                        <a href="#" class="btn-enroll" style="background:#f39c12;"><i class="fas fa-pencil-alt"></i> Submit</a>
                    </div>
                    <div class="assignment-item" style="padding:15px;border-bottom:1px solid #eee;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;">
                        <div>
                            <h4>Java Assignment #3</h4>
                            <p style="color:#666;font-size:0.9rem;">Due: 5 days</p>
                        </div>
                        <a href="#" class="btn-enroll" style="background:#f39c12;"><i class="fas fa-pencil-alt"></i> Submit</a>
                    </div>
                    <div class="assignment-item" style="padding:15px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;">
                        <div>
                            <h4>Python Data Analysis</h4>
                            <p style="color:#666;font-size:0.9rem;">Due: 7 days</p>
                        </div>
                        <a href="#" class="btn-enroll" style="background:#f39c12;"><i class="fas fa-pencil-alt"></i> Submit</a>
                    </div>
                </div>

                <!-- Completed Assignments -->
                <div style="background:rgba(255,255,255,0.95);padding:20px;border-radius:15px;box-shadow:0 5px 20px rgba(0,0,0,0.1);">
                    <h3 style="color:#27ae60;margin-bottom:15px;"><i class="fas fa-check-circle"></i> Completed Assignments</h3>
                    <div class="assignment-item" style="padding:15px;border-bottom:1px solid #eee;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;">
                        <div>
                            <h4>HTML/CSS Project</h4>
                            <p style="color:#666;font-size:0.9rem;">Grade: 85%</p>
                        </div>
                        <span style="color:#27ae60;"><i class="fas fa-check-circle"></i> Completed</span>
                    </div>
                    <div class="assignment-item" style="padding:15px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;">
                        <div>
                            <h4>Java Basics Quiz</h4>
                            <p style="color:#666;font-size:0.9rem;">Grade: 92%</p>
                        </div>
                        <span style="color:#27ae60;"><i class="fas fa-check-circle"></i> Completed</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html>