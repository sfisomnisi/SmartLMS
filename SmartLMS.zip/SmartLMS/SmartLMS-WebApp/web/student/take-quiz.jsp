<%@ page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Smart LMS - Quiz Result</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
    <%
        HttpSession userSession = request.getSession(false);
        User user = (User) userSession.getAttribute("user");
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/public/login.jsp");
            return;
        }
        
        int score = (int) request.getAttribute("score");
        int total = (int) request.getAttribute("total");
        boolean passed = (boolean) request.getAttribute("passed");
        int percentage = (score * 100) / total;
    %>

    <div style="max-width:600px;margin:100px auto;padding:20px;">
        <div style="background:white;padding:40px;border-radius:15px;box-shadow:0 20px 60px rgba(0,0,0,0.1);text-align:center;">
            <h2 style="color:#2c3e50;">Quiz Results</h2>
            
            <div style="margin:30px 0;">
                <% if (passed) { %>
                    <i class="fas fa-check-circle" style="font-size:5rem;color:#27ae60;"></i>
                    <h3 style="color:#27ae60;margin-top:10px;">Congratulations! You Passed!</h3>
                <% } else { %>
                    <i class="fas fa-times-circle" style="font-size:5rem;color:#e74c3c;"></i>
                    <h3 style="color:#e74c3c;margin-top:10px;">Better Luck Next Time!</h3>
                <% } %>
            </div>
            
            <div style="font-size:3rem;font-weight:700;color:#4a90d9;">
                <%= score %> / <%= total %>
            </div>
            <p style="color:#666;font-size:1.2rem;"><%= percentage %>%</p>
            
            <div style="margin-top:30px;display:flex;gap:15px;justify-content:center;flex-wrap:wrap;">
                <a href="${pageContext.request.contextPath}/student/dashboard.jsp" class="btn-get-started btn-get-started-sm">
                    <i class="fas fa-home"></i> Dashboard
                </a>
                <a href="${pageContext.request.contextPath}/student/courses.jsp" class="btn-explore-sm">
                    <i class="fas fa-book"></i> Courses
                </a>
            </div>
        </div>
    </div>
</body>
</html>