<%@ page contentType="text/html" pageEncoding="UTF-8"%>
<%@ page import="java.util.*, smartlms.learn.ejb.*" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Smart LMS - Grades</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body style="background-image: url('${pageContext.request.contextPath}/images/backgrounds/dashboard-bg.jpg'); background-size: cover; background-position: center;">

    <%
        HttpSession userSession = request.getSession(false);
        User user = (User) userSession.getAttribute("user");
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/public/login.jsp");
            return;
        }
    %>

    <div class="dashboard-container">
        <div class="sidebar">
            <div class="sidebar-logo">
                <img src="${pageContext.request.contextPath}/images/logo/logo-white.png" alt="Smart LMS" width="80">
                <h3 style="color:white;">Smart LMS</h3>
            </div>
            <nav class="sidebar-menu">
                <a href="${pageContext.request.contextPath}/student/dashboard.jsp"><i class="fas fa-home"></i> Dashboard</a>
                <a href="${pageContext.request.contextPath}/enrollments?action=my-courses"><i class="fas fa-book"></i> My Courses</a>
                <a href="${pageContext.request.contextPath}/student/assignments.jsp"><i class="fas fa-tasks"></i> Assignments</a>
                <a href="${pageContext.request.contextPath}/student/grades.jsp" class="active"><i class="fas fa-grade"></i> Grades</a>
                <a href="${pageContext.request.contextPath}/student/discussions.jsp"><i class="fas fa-users"></i> Discussions</a>
                <a href="${pageContext.request.contextPath}/student/profile.jsp"><i class="fas fa-user"></i> Profile</a>
                <a href="${pageContext.request.contextPath}/logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </nav>
        </div>
        
        <div class="main-content">
            <div class="dashboard-header">
                <h2 style="color:white;"><i class="fas fa-grade" style="color:#4a90d9;"></i> My Grades</h2>
                <div class="user-info">
                    <img src="${pageContext.request.contextPath}/images/avatars/student-avatar.png" alt="Avatar" width="40" class="avatar">
                    <span style="color:white;"><%= user.getFullName() %></span>
                </div>
            </div>

            <div style="background:rgba(255,255,255,0.95);padding:20px;border-radius:15px;box-shadow:0 5px 20px rgba(0,0,0,0.1);margin-top:20px;">
                <table style="width:100%;border-collapse:collapse;">
                    <thead>
                        <tr style="background:#2c3e50;color:white;border-radius:10px;">
                            <th style="padding:12px;text-align:left;">Course</th>
                            <th style="padding:12px;text-align:left;">Assignment</th>
                            <th style="padding:12px;text-align:left;">Grade</th>
                            <th style="padding:12px;text-align:left;">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr style="border-bottom:1px solid #eee;">
                            <td style="padding:12px;">Java Programming</td>
                            <td style="padding:12px;">Java Basics Quiz</td>
                            <td style="padding:12px;color:#27ae60;font-weight:700;">92%</td>
                            <td style="padding:12px;"><span style="color:#27ae60;"><i class="fas fa-check-circle"></i> Passed</span></td>
                        </tr>
                        <tr style="border-bottom:1px solid #eee;">
                            <td style="padding:12px;">Web Development</td>
                            <td style="padding:12px;">HTML/CSS Project</td>
                            <td style="padding:12px;color:#27ae60;font-weight:700;">85%</td>
                            <td style="padding:12px;"><span style="color:#27ae60;"><i class="fas fa-check-circle"></i> Passed</span></td>
                        </tr>
                        <tr style="border-bottom:1px solid #eee;">
                            <td style="padding:12px;">Python Data Science</td>
                            <td style="padding:12px;">Data Analysis Project</td>
                            <td style="padding:12px;color:#f39c12;font-weight:700;">Pending</td>
                            <td style="padding:12px;"><span style="color:#f39c12;"><i class="fas fa-clock"></i> In Progress</span></td>
                        </tr>
                        <tr>
                            <td style="padding:12px;">Cloud Computing</td>
                            <td style="padding:12px;">AWS Quiz</td>
                            <td style="padding:12px;color:#e74c3c;font-weight:700;">Not Submitted</td>
                            <td style="padding:12px;"><span style="color:#e74c3c;"><i class="fas fa-times-circle"></i> Pending</span></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</body>
</html>