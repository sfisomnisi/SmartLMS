<%@ page contentType="text/html" pageEncoding="UTF-8"%>
<%@ page import="java.util.*, smartlms.learn.ejb.*" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart LMS - Dashboard</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
    <link rel="icon" href="${pageContext.request.contextPath}/images/logo/favicon.ico">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body style="background-image: url('${pageContext.request.contextPath}/images/backgrounds/dashboard-bg.jpg'); background-size: cover; background-position: center;">

    <%
        // Get session and user
        HttpSession userSession = request.getSession(false);
        User user = (User) userSession.getAttribute("user");
        String fullName = (String) userSession.getAttribute("fullName");
        String role = (String) userSession.getAttribute("role");
        
        // If not logged in, redirect to login
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/public/login.jsp");
            return;
        }
        
        // Get data from request attributes (set by servlet)
        int enrolledCount = request.getAttribute("enrolledCount") != null ? (int) request.getAttribute("enrolledCount") : 0;
        int completedCount = request.getAttribute("completedCount") != null ? (int) request.getAttribute("completedCount") : 0;
        int avgProgress = request.getAttribute("avgProgress") != null ? (int) request.getAttribute("avgProgress") : 0;
        int pendingAssignments = request.getAttribute("pendingAssignments") != null ? (int) request.getAttribute("pendingAssignments") : 0;
        List<Enrollment> enrollments = (List<Enrollment>) request.getAttribute("enrollments");
    %>

    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-logo">
                <img src="${pageContext.request.contextPath}/images/logo/logo-white.png" alt="Smart LMS" width="80">
                <h3 style="color:white;">Smart LMS</h3>
            </div>
            <nav class="sidebar-menu">
                <a href="${pageContext.request.contextPath}/student/dashboard.jsp" class="active"><i class="fas fa-home"></i> Dashboard</a>
                <a href="${pageContext.request.contextPath}/enrollments?action=my-courses"><i class="fas fa-book"></i> My Courses</a>
                <a href="${pageContext.request.contextPath}/student/courses.jsp"><i class="fas fa-search"></i> Browse Courses</a>
                <a href="${pageContext.request.contextPath}/student/assignments.jsp"><i class="fas fa-tasks"></i> Assignments</a>
                <a href="${pageContext.request.contextPath}/student/grades.jsp"><i class="fas fa-grade"></i> Grades</a>
                <a href="${pageContext.request.contextPath}/student/discussions.jsp"><i class="fas fa-users"></i> Discussions</a>
                <a href="${pageContext.request.contextPath}/student/profile.jsp"><i class="fas fa-user"></i> Profile</a>
                <a href="${pageContext.request.contextPath}/logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </nav>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="dashboard-header">
                <h2 style="color:white;"><i class="fas fa-user-graduate" style="color:#4a90d9;"></i> Welcome, <span style="color:white;"><%= fullName != null ? fullName : "Student" %></span>!</h2>
                <div class="user-info">
                    <img src="${pageContext.request.contextPath}/images/avatars/student-avatar.png" alt="Avatar" width="40" class="avatar">
                    <span style="color:white;"><%= role != null ? role : "STUDENT" %></span>
                </div>
            </div>
            
            <!-- Stats Grid -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-book-open"></i></div>
                    <div class="stat-number"><%= enrolledCount %></div>
                    <div class="stat-label">Enrolled Courses</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-clock"></i></div>
                    <div class="stat-number"><%= pendingAssignments %></div>
                    <div class="stat-label">Pending Assignments</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
                    <div class="stat-number"><%= completedCount %></div>
                    <div class="stat-label">Completed Courses</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-star"></i></div>
                    <div class="stat-number"><%= avgProgress %>%</div>
                    <div class="stat-label">Overall Progress</div>
                </div>
            </div>
            
            <!-- Get Started Section -->
            <div class="get-started-section">
                <div>
                    <h3><i class="fas fa-rocket"></i> Ready to Learn More?</h3>
                    <p>Explore new courses and expand your skills today!</p>
                </div>
                <a href="${pageContext.request.contextPath}/student/courses.jsp" class="btn-get-started-sm" style="background:white;color:#6D28D9!important;padding:12px 30px;border-radius:50px;font-weight:700;text-decoration:none;display:inline-flex;align-items:center;gap:8px;transition:all .3s;">
                    <i class="fas fa-arrow-right" style="color:#6D28D9;"></i> Browse Courses
                </a>
            </div>
            
            <!-- Recent Activity -->
            <div class="recent-activity">
                <h3><i class="fas fa-clock"></i> Recent Activity</h3>
                <ul class="activity-list">
                    <%
                        if (enrollments != null && !enrollments.isEmpty()) {
                            for (int i = 0; i < Math.min(enrollments.size(), 3); i++) {
                                Enrollment e = enrollments.get(i);
                                Course c = e.getCourse();
                    %>
                        <li>
                            <i class="fas fa-check-circle" style="color: #27ae60;"></i>
                            Enrolled in "<%= c.getTitle() %>" on <%= new java.text.SimpleDateFormat("dd MMM yyyy").format(e.getEnrolledAt()) %>
                        </li>
                    <%
                            }
                        } else {
                    %>
                        <li><i class="fas fa-info-circle" style="color: #3498db;"></i> No recent activity. <a href="${pageContext.request.contextPath}/student/courses.jsp" style="color:#4a90d9;">Browse courses</a> to start learning!</li>
                    <%
                        }
                    %>
                    <li><i class="fas fa-clock" style="color: #f39c12;"></i> Assignment "Web Project" due in 2 days</li>
                    <li><i class="fas fa-comment" style="color: #3498db;"></i> New discussion in "Java Programming"</li>
                </ul>
            </div>
        </div>
    </div>

</body>
</html>