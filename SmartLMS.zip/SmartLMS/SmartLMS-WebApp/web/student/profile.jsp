<%@ page contentType="text/html" pageEncoding="UTF-8"%>
<%@ page import="java.util.*, smartlms.learn.ejb.*" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Smart LMS - Profile</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body style="background-image: url('${pageContext.request.contextPath}/images/backgrounds/dashboard-bg.jpg'); background-size: cover; background-position: center;">

    <%
        HttpSession userSession = request.getSession(false);
        User user = (User) userSession.getAttribute("user");
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/public/login.jsp");
            return;
        }
    %>

    <div class="dashboard-container">
        <div class="sidebar">
            <div class="sidebar-logo">
                <img src="${pageContext.request.contextPath}/images/logo/logo-white.png" alt="Smart LMS" width="80">
                <h3 style="color:white;">Smart LMS</h3>
            </div>
            <nav class="sidebar-menu">
                <a href="${pageContext.request.contextPath}/student/dashboard.jsp"><i class="fas fa-home"></i> Dashboard</a>
                <a href="${pageContext.request.contextPath}/enrollments?action=my-courses"><i class="fas fa-book"></i> My Courses</a>
                <a href="${pageContext.request.contextPath}/student/assignments.jsp"><i class="fas fa-tasks"></i> Assignments</a>
                <a href="${pageContext.request.contextPath}/student/grades.jsp"><i class="fas fa-grade"></i> Grades</a>
                <a href="${pageContext.request.contextPath}/student/discussions.jsp"><i class="fas fa-users"></i> Discussions</a>
                <a href="${pageContext.request.contextPath}/student/profile.jsp" class="active"><i class="fas fa-user"></i> Profile</a>
                <a href="${pageContext.request.contextPath}/logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </nav>
        </div>
        
        <div class="main-content">
            <div class="dashboard-header">
                <h2 style="color:white;"><i class="fas fa-user" style="color:#4a90d9;"></i> My Profile</h2>
                <div class="user-info">
                    <img src="${pageContext.request.contextPath}/images/avatars/student-avatar.png" alt="Avatar" width="40" class="avatar">
                    <span style="color:white;"><%= user.getFullName() %></span>
                </div>
            </div>

            <div style="display:grid;grid-template-columns:1fr 2fr;gap:30px;margin-top:20px;">
                <!-- Profile Picture -->
                <div style="background:rgba(255,255,255,0.95);padding:30px;border-radius:15px;text-align:center;box-shadow:0 5px 20px rgba(0,0,0,0.1);">
                    <img src="${pageContext.request.contextPath}/images/avatars/student-avatar.png" alt="Profile" style="width:150px;height:150px;border-radius:50%;border:4px solid #4a90d9;margin-bottom:15px;">
                    <h3 style="color:#2c3e50;"><%= user.getFullName() %></h3>
                    <p style="color:#666;"><%= user.getRole() %></p>
                    <button class="btn-get-started btn-get-started-sm" style="margin-top:15px;"><i class="fas fa-camera"></i> Change Photo</button>
                </div>

                <!-- Profile Details -->
                <div style="background:rgba(255,255,255,0.95);padding:30px;border-radius:15px;box-shadow:0 5px 20px rgba(0,0,0,0.1);">
                    <h3 style="color:#2c3e50;margin-bottom:20px;"><i class="fas fa-edit"></i> Edit Profile</h3>
                    <form action="${pageContext.request.contextPath}/profile" method="post">
                        <div style="margin-bottom:15px;">
                            <label style="font-weight:600;display:block;margin-bottom:5px;">Full Name</label>
                            <input type="text" name="fullName" value="<%= user.getFullName() %>" style="width:100%;padding:12px;border:2px solid #e0e0e0;border-radius:8px;font-size:16px;">
                        </div>
                        <div style="margin-bottom:15px;">
                            <label style="font-weight:600;display:block;margin-bottom:5px;">Email Address</label>
                            <input type="email" name="email" value="<%= user.getEmail() %>" style="width:100%;padding:12px;border:2px solid #e0e0e0;border-radius:8px;font-size:16px;">
                        </div>
                        <div style="margin-bottom:15px;">
                            <label style="font-weight:600;display:block;margin-bottom:5px;">Bio</label>
                            <textarea name="bio" rows="3" style="width:100%;padding:12px;border:2px solid #e0e0e0;border-radius:8px;font-size:16px;resize:vertical;">Student at Smart LMS. Passionate about learning new technologies.</textarea>
                        </div>
                        <button type="submit" class="btn-get-started btn-get-started-sm"><i class="fas fa-save"></i> Save Changes</button>
                    </form>

                    <hr style="margin:20px 0;border:none;border-top:1px solid #eee;">

                    <h4 style="color:#2c3e50;margin-bottom:10px;"><i class="fas fa-lock"></i> Change Password</h4>
                    <form action="${pageContext.request.contextPath}/profile" method="post" style="margin-top:10px;">
                        <input type="hidden" name="action" value="changePassword">
                        <div style="margin-bottom:10px;">
                            <input type="password" name="currentPassword" placeholder="Current Password" style="width:100%;padding:12px;border:2px solid #e0e0e0;border-radius:8px;font-size:16px;">
                        </div>
                        <div style="margin-bottom:10px;">
                            <input type="password" name="newPassword" placeholder="New Password" style="width:100%;padding:12px;border:2px solid #e0e0e0;border-radius:8px;font-size:16px;">
                        </div>
                        <div style="margin-bottom:10px;">
                            <input type="password" name="confirmPassword" placeholder="Confirm New Password" style="width:100%;padding:12px;border:2px solid #e0e0e0;border-radius:8px;font-size:16px;">
                        </div>
                        <button type="submit" class="btn-enroll" style="background:#e74c3c;"><i class="fas fa-key"></i> Update Password</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

</body>
</html>