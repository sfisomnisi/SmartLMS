<%@ page contentType="text/html" pageEncoding="UTF-8"%>
<%@ page import="java.util.*, smartlms.learn.ejb.*" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Smart LMS - Browse Courses</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body style="background-image: url('${pageContext.request.contextPath}/images/backgrounds/dashboard-bg.jpg'); background-size: cover; background-position: center;">

    <%
        HttpSession userSession = request.getSession(false);
        User user = (User) userSession.getAttribute("user");
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/public/login.jsp");
            return;
        }
        
        // Get courses from request attribute (set by servlet)
        List<Course> courses = (List<Course>) request.getAttribute("courses");
        Long studentId = user.getId();
        
        // Get enrollment status from request attribute
        Map<Long, Boolean> enrolledMap = (Map<Long, Boolean>) request.getAttribute("enrolledMap");
    %>

    <div class="dashboard-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-logo">
                <img src="${pageContext.request.contextPath}/images/logo/logo-white.png" alt="Smart LMS" width="80">
                <h3 style="color:white;">Smart LMS</h3>
            </div>
            <nav class="sidebar-menu">
                <a href="${pageContext.request.contextPath}/student/dashboard.jsp"><i class="fas fa-home"></i> Dashboard</a>
                <a href="${pageContext.request.contextPath}/enrollments?action=my-courses"><i class="fas fa-book"></i> My Courses</a>
                <a href="${pageContext.request.contextPath}/student/courses.jsp" class="active"><i class="fas fa-search"></i> Browse Courses</a>
                <a href="${pageContext.request.contextPath}/student/assignments.jsp"><i class="fas fa-tasks"></i> Assignments</a>
                <a href="${pageContext.request.contextPath}/student/grades.jsp"><i class="fas fa-grade"></i> Grades</a>
                <a href="${pageContext.request.contextPath}/student/discussions.jsp"><i class="fas fa-users"></i> Discussions</a>
                <a href="${pageContext.request.contextPath}/student/profile.jsp"><i class="fas fa-user"></i> Profile</a>
                <a href="${pageContext.request.contextPath}/logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </nav>
        </div>
        
        <div class="main-content">
            <div class="dashboard-header">
                <h2 style="color:white;"><i class="fas fa-search" style="color:#4a90d9;"></i> Available Courses</h2>
                <div class="user-info">
                    <img src="${pageContext.request.contextPath}/images/avatars/student-avatar.png" alt="Avatar" width="40" class="avatar">
                    <span style="color:white;"><%= user.getFullName() %></span>
                </div>
            </div>

            <div class="courses-grid" style="margin-top:20px;">
                <%
                    if (courses != null && !courses.isEmpty()) {
                        for (Course course : courses) {
                            // Check if student is enrolled - using map from servlet
                            boolean isEnrolled = enrolledMap != null && enrolledMap.containsKey(course.getId()) && enrolledMap.get(course.getId());
                %>
                <div class="course-card">
                    <img src="${pageContext.request.contextPath}/images/course-thumbnails/<%= course.getId() %>.jpg" 
                         alt="<%= course.getTitle() %>" 
                         onerror="this.src='https://placehold.co/400x250/4A90D9/FFFFFF?text=<%= course.getTitle().replace(' ', '+') %>'">
                    <div class="course-info">
                        <h3><%= course.getTitle() %></h3>
                        <p><%= course.getDescription() %></p>
                        <span class="course-price">R <%= course.getPrice() %></span>
                        
                        <%
                            if (isEnrolled) {
                        %>
                            <span style="display:inline-block;padding:10px 25px;background:#27ae60;color:#fff;border-radius:50px;font-weight:700;margin-top:10px;">
                                <i class="fas fa-check-circle"></i> Enrolled
                            </span>
                            <a href="${pageContext.request.contextPath}/course-details?courseId=<%= course.getId() %>" 
                               class="btn-enroll" style="margin-top:10px;display:inline-block;">
                                <i class="fas fa-eye"></i> View Course
                            </a>
                        <%
                            } else {
                        %>
                            <a href="${pageContext.request.contextPath}/enrollments?action=enroll&courseId=<%= course.getId() %>" 
                               class="btn-enroll" style="margin-top:10px;">
                                <i class="fas fa-plus-circle"></i> Enroll Now
                            </a>
                        <%
                            }
                        %>
                    </div>
                </div>
                <%
                        }
                    } else {
                %>
                <div style="grid-column:1/-1;text-align:center;padding:60px 20px;background:rgba(255,255,255,0.95);border-radius:15px;">
                    <i class="fas fa-info-circle" style="font-size:4rem;color:#ddd;"></i>
                    <h3 style="color:#666;margin-top:20px;">No courses available at the moment</h3>
                    <p style="color:#999;">Check back later for new courses!</p>
                </div>
                <%
                    }
                %>
            </div>
        </div>
    </div>

</body>
</html>