<%@ page contentType="text/html" pageEncoding="UTF-8"%>
<%@ page import="java.util.*, smartlms.learn.ejb.*" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Smart LMS - Course Details</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body style="background-image: url('${pageContext.request.contextPath}/images/backgrounds/dashboard-bg.jpg'); background-size: cover; background-position: center;">

    <%
        HttpSession userSession = request.getSession(false);
        User user = (User) userSession.getAttribute("user");
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/public/login.jsp");
            return;
        }
        
        Course course = (Course) request.getAttribute("course");
        Enrollment enrollment = (Enrollment) request.getAttribute("enrollment");
        List<Assignment> assignments = (List<Assignment>) request.getAttribute("assignments");
        List<Quiz> quizzes = (List<Quiz>) request.getAttribute("quizzes");
    %>

    <div class="dashboard-container">
        <div class="sidebar">
            <div class="sidebar-logo">
                <img src="${pageContext.request.contextPath}/images/logo/logo-white.png" alt="Smart LMS" width="80">
                <h3 style="color:white;">Smart LMS</h3>
            </div>
            <nav class="sidebar-menu">
                <a href="${pageContext.request.contextPath}/student/dashboard.jsp"><i class="fas fa-home"></i> Dashboard</a>
                <a href="${pageContext.request.contextPath}/enrollments?action=my-courses" class="active"><i class="fas fa-book"></i> My Courses</a>
                <a href="${pageContext.request.contextPath}/student/assignments.jsp"><i class="fas fa-tasks"></i> Assignments</a>
                <a href="${pageContext.request.contextPath}/student/grades.jsp"><i class="fas fa-grade"></i> Grades</a>
                <a href="${pageContext.request.contextPath}/logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </nav>
        </div>
        
        <div class="main-content">
            <div class="dashboard-header">
                <h2 style="color:white;"><i class="fas fa-book" style="color:#4a90d9;"></i> <%= course.getTitle() %></h2>
                <div class="user-info">
                    <img src="${pageContext.request.contextPath}/images/avatars/student-avatar.png" alt="Avatar" width="40" class="avatar">
                    <span style="color:white;"><%= user.getFullName() %></span>
                </div>
            </div>

            <!-- Course Progress -->
            <div style="background:rgba(255,255,255,0.95);padding:20px;border-radius:15px;margin-bottom:20px;box-shadow:0 5px 20px rgba(0,0,0,0.1);">
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;">
                    <div>
                        <h3 style="color:#2c3e50;"><%= course.getTitle() %></h3>
                        <p style="color:#666;"><%= course.getDescription() %></p>
                    </div>
                    <div style="text-align:center;">
                        <span style="font-size:2rem;font-weight:700;color:#4a90d9;"><%= enrollment.getProgress() %>%</span>
                        <p style="color:#666;">Progress</p>
                    </div>
                </div>
                <div style="width:100%;height:10px;background:#e0e0e0;border-radius:10px;overflow:hidden;margin-top:10px;">
                    <div style="width:<%= enrollment.getProgress() %>% ;height:100%;background:linear-gradient(90deg,#4a90d9,#6D28D9);border-radius:10px;"></div>
                </div>
            </div>

            <!-- Assignments -->
            <div style="background:rgba(255,255,255,0.95);padding:20px;border-radius:15px;margin-bottom:20px;box-shadow:0 5px 20px rgba(0,0,0,0.1);">
                <h3 style="color:#2c3e50;margin-bottom:15px;"><i class="fas fa-tasks"></i> Assignments</h3>
                <% if (assignments != null && !assignments.isEmpty()) { %>
                    <% for (Assignment assignment : assignments) { %>
                        <div style="padding:15px;border-bottom:1px solid #eee;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;">
                            <div>
                                <h4><%= assignment.getTitle() %></h4>
                                <p style="color:#666;font-size:0.9rem;">Due: <%= assignment.getDueDate() %></p>
                            </div>
                            <a href="${pageContext.request.contextPath}/assignments/submit?assignmentId=<%= assignment.getId() %>" class="btn-enroll"><i class="fas fa-upload"></i> Submit</a>
                        </div>
                    <% } %>
                <% } else { %>
                    <p style="color:#666;">No assignments yet.</p>
                <% } %>
            </div>

            <!-- Quizzes -->
            <div style="background:rgba(255,255,255,0.95);padding:20px;border-radius:15px;box-shadow:0 5px 20px rgba(0,0,0,0.1);">
                <h3 style="color:#2c3e50;margin-bottom:15px;"><i class="fas fa-question-circle"></i> Quizzes</h3>
                <% if (quizzes != null && !quizzes.isEmpty()) { %>
                    <% for (Quiz quiz : quizzes) { %>
                        <div style="padding:15px;border-bottom:1px solid #eee;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;">
                            <div>
                                <h4><%= quiz.getTitle() %></h4>
                                <p style="color:#666;font-size:0.9rem;">10 Questions</p>
                            </div>
                            <a href="${pageContext.request.contextPath}/quizzes/take?quizId=<%= quiz.getId() %>" class="btn-enroll" style="background:#6D28D9;"><i class="fas fa-play"></i> Take Quiz</a>
                        </div>
                    <% } %>
                <% } else { %>
                    <p style="color:#666;">No quizzes yet.</p>
                <% } %>
            </div>
        </div>
    </div>
</body>
</html>