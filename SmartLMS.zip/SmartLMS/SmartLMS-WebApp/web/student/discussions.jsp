<%@ page contentType="text/html" pageEncoding="UTF-8"%>
<%@ page import="java.util.*, smartlms.learn.ejb.*" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Smart LMS - Discussions</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body style="background-image: url('${pageContext.request.contextPath}/images/backgrounds/dashboard-bg.jpg'); background-size: cover; background-position: center;">

    <%
        HttpSession userSession = request.getSession(false);
        User user = (User) userSession.getAttribute("user");
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/public/login.jsp");
            return;
        }
    %>

    <div class="dashboard-container">
        <div class="sidebar">
            <div class="sidebar-logo">
                <img src="${pageContext.request.contextPath}/images/logo/logo-white.png" alt="Smart LMS" width="80">
                <h3 style="color:white;">Smart LMS</h3>
            </div>
            <nav class="sidebar-menu">
                <a href="${pageContext.request.contextPath}/student/dashboard.jsp"><i class="fas fa-home"></i> Dashboard</a>
                <a href="${pageContext.request.contextPath}/enrollments?action=my-courses"><i class="fas fa-book"></i> My Courses</a>
                <a href="${pageContext.request.contextPath}/student/assignments.jsp"><i class="fas fa-tasks"></i> Assignments</a>
                <a href="${pageContext.request.contextPath}/student/grades.jsp"><i class="fas fa-grade"></i> Grades</a>
                <a href="${pageContext.request.contextPath}/student/discussions.jsp" class="active"><i class="fas fa-users"></i> Discussions</a>
                <a href="${pageContext.request.contextPath}/student/profile.jsp"><i class="fas fa-user"></i> Profile</a>
                <a href="${pageContext.request.contextPath}/logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </nav>
        </div>
        
        <div class="main-content">
            <div class="dashboard-header">
                <h2 style="color:white;"><i class="fas fa-users" style="color:#4a90d9;"></i> Discussions</h2>
                <div class="user-info">
                    <img src="${pageContext.request.contextPath}/images/avatars/student-avatar.png" alt="Avatar" width="40" class="avatar">
                    <span style="color:white;"><%= user.getFullName() %></span>
                </div>
            </div>

            <!-- Create New Discussion -->
            <div style="background:rgba(255,255,255,0.95);padding:20px;border-radius:15px;margin-bottom:20px;box-shadow:0 5px 20px rgba(0,0,0,0.1);">
                <h3 style="color:#2c3e50;margin-bottom:15px;"><i class="fas fa-plus-circle"></i> Start New Discussion</h3>
                <form action="${pageContext.request.contextPath}/discussions" method="post">
                    <input type="hidden" name="action" value="create">
                    <div style="margin-bottom:10px;">
                        <input type="text" name="title" placeholder="Discussion Title" required style="width:100%;padding:12px;border:2px solid #e0e0e0;border-radius:8px;font-size:16px;">
                    </div>
                    <div style="margin-bottom:10px;">
                        <textarea name="content" placeholder="What's on your mind?" rows="3" required style="width:100%;padding:12px;border:2px solid #e0e0e0;border-radius:8px;font-size:16px;resize:vertical;"></textarea>
                    </div>
                    <button type="submit" class="btn-get-started btn-get-started-sm"><i class="fas fa-paper-plane"></i> Post Discussion</button>
                </form>
            </div>

            <!-- Discussion List -->
            <div style="background:rgba(255,255,255,0.95);padding:20px;border-radius:15px;box-shadow:0 5px 20px rgba(0,0,0,0.1);">
                <h3 style="color:#2c3e50;margin-bottom:15px;"><i class="fas fa-comments"></i> Recent Discussions</h3>
                
                <div class="discussion-item" style="padding:15px;border-bottom:1px solid #eee;">
                    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;">
                        <div>
                            <h4>Welcome to Java Programming!</h4>
                            <p style="color:#666;font-size:0.9rem;">Posted by: Dr. John Smith • 2 hours ago</p>
                            <p style="color:#555;margin-top:5px;">Welcome everyone! Please introduce yourselves.</p>
                        </div>
                        <a href="#" class="btn-enroll" style="background:#4a90d9;padding:8px 20px;"><i class="fas fa-reply"></i> Reply</a>
                    </div>
                </div>
                
                <div class="discussion-item" style="padding:15px;border-bottom:1px solid #eee;">
                    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;">
                        <div>
                            <h4>Question about loops</h4>
                            <p style="color:#666;font-size:0.9rem;">Posted by: Jane Student • 5 hours ago</p>
                            <p style="color:#555;margin-top:5px;">Can someone explain for-each loops?</p>
                        </div>
                        <a href="#" class="btn-enroll" style="background:#4a90d9;padding:8px 20px;"><i class="fas fa-reply"></i> Reply</a>
                    </div>
                </div>
                
                <div class="discussion-item" style="padding:15px;">
                    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;">
                        <div>
                            <h4>Project Deadline Extension</h4>
                            <p style="color:#666;font-size:0.9rem;">Posted by: Dr. John Smith • 1 day ago</p>
                            <p style="color:#555;margin-top:5px;">The HTML/CSS project deadline has been extended by 2 days.</p>
                        </div>
                        <a href="#" class="btn-enroll" style="background:#4a90d9;padding:8px 20px;"><i class="fas fa-reply"></i> Reply</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html>