<%@ page contentType="text/html" pageEncoding="UTF-8"%>
<%@ page import="java.util.*, smartlms.learn.ejb.*" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Smart LMS - My Courses</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body style="background-image: url('${pageContext.request.contextPath}/images/backgrounds/dashboard-bg.jpg'); background-size: cover; background-position: center;">

    <%
        HttpSession userSession = request.getSession();
        User user = (User) userSession.getAttribute("user");
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/public/login.jsp");
            return;
        }
    %>

    <div class="dashboard-container">
        <div class="sidebar">
            <div class="sidebar-logo">
                <img src="${pageContext.request.contextPath}/images/logo/logo-white.png" alt="Smart LMS" width="80">
                <h3>Smart LMS</h3>
            </div>
            <nav class="sidebar-menu">
                <a href="${pageContext.request.contextPath}/student/dashboard.jsp"><i class="fas fa-home"></i> Dashboard</a>
                <a href="${pageContext.request.contextPath}/student/courses.jsp"><i class="fas fa-book"></i> All Courses</a>
                <a href="${pageContext.request.contextPath}/enrollments?action=my-courses" class="active"><i class="fas fa-book-open"></i> My Courses</a>
                <a href="${pageContext.request.contextPath}/student/assignments.jsp"><i class="fas fa-tasks"></i> Assignments</a>
                <a href="${pageContext.request.contextPath}/student/profile.jsp"><i class="fas fa-user"></i> Profile</a>
                <a href="${pageContext.request.contextPath}/logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </nav>
        </div>
        
        <div class="main-content">
            <div class="dashboard-header">
                <h2><i class="fas fa-book-open"></i> My Enrolled Courses</h2>
                <div class="user-info">
                    <img src="${pageContext.request.contextPath}/images/avatars/student-avatar.png" alt="Avatar" width="40" class="avatar">
                    <span><%= user.getFullName() %></span>
                </div>
            </div>

            <!-- Display Messages -->
            <%
                String message = (String) request.getAttribute("message");
                String messageType = (String) request.getAttribute("messageType");
                if (message != null) {
                    String alertClass = "alert-success";
                    if ("error".equals(messageType)) alertClass = "alert-error";
                    else if ("warning".equals(messageType)) alertClass = "alert-warning";
                    else if ("info".equals(messageType)) alertClass = "alert-info";
            %>
                <div class="alert <%= alertClass %>" style="margin-bottom:20px;">
                    <i class="fas fa-info-circle"></i> <%= message %>
                </div>
            <%
                }
            %>

            <div class="courses-grid" style="margin-top:20px;">
                <%
                    List<Enrollment> enrollments = (List<Enrollment>) request.getAttribute("enrollments");
                    if (enrollments != null && !enrollments.isEmpty()) {
                        for (Enrollment enrollment : enrollments) {
                            Course course = enrollment.getCourse();
                            int progress = enrollment.getProgress();
                            boolean completed = enrollment.isCompleted();
                %>
                <div class="course-card">
                    <img src="${pageContext.request.contextPath}/images/course-thumbnails/<%= course.getId() %>.jpg" 
                         alt="<%= course.getTitle() %>" 
                         onerror="this.src='https://placehold.co/400x250/4A90D9/FFFFFF?text=<%= course.getTitle().replace(' ', '+') %>'">
                    <div class="course-info">
                        <h3><%= course.getTitle() %></h3>
                        <p><%= course.getDescription() %></p>
                        
                        <!-- Progress Bar -->
                        <div style="margin:15px 0;">
                            <div style="display:flex;justify-content:space-between;margin-bottom:5px;">
                                <span style="font-weight:600;">Progress</span>
                                <span style="color:#4a90d9;font-weight:700;"><%= progress %>%</span>
                            </div>
                            <div style="width:100%;height:10px;background:#e0e0e0;border-radius:10px;overflow:hidden;">
                                <div style="width:<%= progress %>% ;height:100%;background:linear-gradient(90deg,#4a90d9,#6D28D9);border-radius:10px;"></div>
                            </div>
                        </div>
                        
                        <%
                            if (completed) {
                        %>
                            <span style="display:inline-block;padding:8px 20px;background:#27ae60;color:#fff;border-radius:50px;font-weight:700;font-size:0.9rem;">
                                <i class="fas fa-certificate"></i> Completed
                            </span>
                        <%
                            } else {
                        %>
                            <span style="display:inline-block;padding:8px 20px;background:#f39c12;color:#fff;border-radius:50px;font-weight:700;font-size:0.9rem;">
                                <i class="fas fa-clock"></i> In Progress
                            </span>
                        <%
                            }
                        %>
                        
                        <a href="${pageContext.request.contextPath}/student/course-details.jsp?courseId=<%= course.getId() %>" 
                           class="btn-enroll" style="margin-top:10px;display:inline-block;">
                            <i class="fas fa-eye"></i> View Course
                        </a>
                        
                        <a href="${pageContext.request.contextPath}/enrollments?action=unenroll&id=<%= enrollment.getId() %>" 
                           class="btn-enroll" style="margin-top:10px;display:inline-block;background:#e74c3c;"
                           onclick="return confirm('Are you sure you want to unenroll from this course?');">
                            <i class="fas fa-times"></i> Unenroll
                        </a>
                    </div>
                </div>
                <%
                        }
                    } else {
                %>
                <div style="grid-column:1/-1;text-align:center;padding:60px 20px;">
                    <i class="fas fa-book-open" style="font-size:4rem;color:#ddd;"></i>
                    <h3 style="color:#666;margin-top:20px;">You haven't enrolled in any courses yet</h3>
                    <p style="color:#999;margin-bottom:20px;">Browse our courses and start learning today!</p>
                    <a href="${pageContext.request.contextPath}/student/courses.jsp" class="btn-get-started btn-get-started-sm">
                        <i class="fas fa-arrow-right"></i> Browse Courses
                    </a>
                </div>
                <%
                    }
                %>
            </div>
        </div>
    </div>

</body>
</html>