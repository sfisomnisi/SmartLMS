<%@ page import="smartlms.learn.ejb.User" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart LMS - Home</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>

    <%
        HttpSession userSession = request.getSession(false);
        User user = (User) (userSession != null ? userSession.getAttribute("user") : null);
        String role = (String) (userSession != null ? userSession.getAttribute("role") : null);
    %>

    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-logo">
                <i class="fas fa-graduation-cap" style="font-size:1.8rem;color:#4a90d9;"></i>
                <span>Smart LMS</span>
            </div>
            <ul class="nav-menu">
                <li><a href="${pageContext.request.contextPath}/public/index.jsp" class="active"><i class="fas fa-home"></i> Home</a></li>
                <li><a href="#courses"><i class="fas fa-book"></i> Courses</a></li>
                <li><a href="#about"><i class="fas fa-info-circle"></i> About</a></li>
                <li><a href="#contact"><i class="fas fa-envelope"></i> Contact</a></li>
                <% if (user != null) { %>
                    <li><a href="${pageContext.request.contextPath}/student/dashboard.jsp"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li><a href="${pageContext.request.contextPath}/logout"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                <% } else { %>
                    <li><a href="${pageContext.request.contextPath}/public/login.jsp" class="btn-login"><i class="fas fa-sign-in-alt"></i> Login</a></li>
                    <li><a href="${pageContext.request.contextPath}/public/register.jsp" class="btn-register"><i class="fas fa-user-plus"></i> Register</a></li>
                <% } %>
            </ul>
        </div>
    </nav>

    <!-- HERO SECTION -->
    <section class="hero" style="background-image: url('${pageContext.request.contextPath}/images/backgrounds/home-bg.jpg');">
        <div class="hero-overlay">
            <div class="hero-content">
                <h1>Welcome to Smart Learning Management System</h1>
                <p>Empowering education through technology. Learn, grow, and succeed with our comprehensive LMS.</p>
                <div class="hero-buttons">
                    <% if (user != null) { %>
                        <a href="${pageContext.request.contextPath}/student/dashboard.jsp" class="btn-get-started">
                            <i class="fas fa-tachometer-alt"></i> Go to Dashboard
                        </a>
                    <% } else { %>
                        <a href="${pageContext.request.contextPath}/public/register.jsp" class="btn-get-started">
                            <i class="fas fa-rocket"></i> Get Started
                        </a>
                    <% } %>
                    <a href="#courses" class="btn-explore">
                        <i class="fas fa-play-circle"></i> Explore Courses
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- FEATURES SECTION -->
    <section class="features" id="features">
        <div class="container">
            <h2 class="section-title">Why Choose Smart LMS?</h2>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon"><i class="fas fa-graduation-cap"></i></div>
                    <h3>Quality Courses</h3>
                    <p>Access to high-quality courses from expert instructors.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon"><i class="fas fa-chart-line"></i></div>
                    <h3>Track Progress</h3>
                    <p>Monitor your learning progress and achievements.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon"><i class="fas fa-users"></i></div>
                    <h3>Community Learning</h3>
                    <p>Engage with peers and instructors through discussions.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon"><i class="fas fa-certificate"></i></div>
                    <h3>Get Certified</h3>
                    <p>Earn certificates upon course completion.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- COURSES SECTION -->
    <section class="courses-section" id="courses" style="background-image: url('${pageContext.request.contextPath}/images/backgrounds/courses-bg.jpg');">
        <div class="overlay-light">
            <div class="container">
                <h2 class="section-title">Popular Courses</h2>
                <div class="courses-grid">
                    <div class="course-card">
                        <img src="${pageContext.request.contextPath}/images/course-thumbnails/java-course.jpg" alt="Java Course">
                        <div class="course-info">
                            <h3>Java Programming</h3>
                            <p>Learn Java from basics to advanced concepts.</p>
                            <span class="course-price">R 499.99</span>
                            <% if (user != null) { %>
                                <a href="${pageContext.request.contextPath}/enrollments?action=enroll&courseId=1" class="btn-enroll"><i class="fas fa-plus-circle"></i> Enroll Now</a>
                            <% } else { %>
                                <a href="${pageContext.request.contextPath}/public/login.jsp" class="btn-enroll"><i class="fas fa-lock"></i> Login to Enroll</a>
                            <% } %>
                        </div>
                    </div>
                    <div class="course-card">
                        <img src="${pageContext.request.contextPath}/images/course-thumbnails/python-course.jpg" alt="Python Course">
                        <div class="course-info">
                            <h3>Python for Data Science</h3>
                            <p>Master Python for data analysis and machine learning.</p>
                            <span class="course-price">R 599.99</span>
                            <% if (user != null) { %>
                                <a href="${pageContext.request.contextPath}/enrollments?action=enroll&courseId=2" class="btn-enroll"><i class="fas fa-plus-circle"></i> Enroll Now</a>
                            <% } else { %>
                                <a href="${pageContext.request.contextPath}/public/login.jsp" class="btn-enroll"><i class="fas fa-lock"></i> Login to Enroll</a>
                            <% } %>
                        </div>
                    </div>
                    <div class="course-card">
                        <img src="${pageContext.request.contextPath}/images/course-thumbnails/web-dev-course.jpg" alt="Web Development">
                        <div class="course-info">
                            <h3>Web Development</h3>
                            <p>Build modern web applications with HTML, CSS, and JavaScript.</p>
                            <span class="course-price">R 399.99</span>
                            <% if (user != null) { %>
                                <a href="${pageContext.request.contextPath}/enrollments?action=enroll&courseId=3" class="btn-enroll"><i class="fas fa-plus-circle"></i> Enroll Now</a>
                            <% } else { %>
                                <a href="${pageContext.request.contextPath}/public/login.jsp" class="btn-enroll"><i class="fas fa-lock"></i> Login to Enroll</a>
                            <% } %>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ABOUT SECTION -->
    <section class="about-section" id="about">
        <div class="container">
            <h2 class="section-title">About Us</h2>
            <div class="about-content">
                <div class="about-text">
                    <p>Smart LMS is a modern learning management system designed to make education accessible, engaging, and effective.</p>
                    <ul class="about-list">
                        <li><i class="fas fa-check-circle"></i> 10,000+ Students</li>
                        <li><i class="fas fa-check-circle"></i> 500+ Courses</li>
                        <li><i class="fas fa-check-circle"></i> 200+ Expert Instructors</li>
                        <li><i class="fas fa-check-circle"></i> 95% Satisfaction Rate</li>
                    </ul>
                </div>
                <div class="about-image">
                    <img src="${pageContext.request.contextPath}/images/banners/hero-banner.jpg" alt="About Smart LMS">
                </div>
            </div>
        </div>
    </section>

    <!-- CONTACT SECTION -->
    <section class="contact-section" id="contact" style="background-image: url('${pageContext.request.contextPath}/images/backgrounds/footer-bg.jpg');">
        <div class="overlay-dark">
            <div class="container">
                <h2 class="section-title text-white">Contact Us</h2>
                <div class="contact-grid">
                    <div class="contact-info">
                        <h3><i class="fas fa-map-marker-alt"></i> Our Location</h3>
                        <p>123 Education Street<br>Smart City, SC 12345<br>South Africa</p>
                        <h3><i class="fas fa-phone"></i> Phone</h3>
                        <p>+27 12 345 6789</p>
                        <h3><i class="fas fa-envelope"></i> Email</h3>
                        <p>info@smartlms.com</p>
                    </div>
                    <div class="contact-form">
                        <h3><i class="fas fa-paper-plane"></i> Send Us a Message</h3>
                        <form action="#" method="post">
                            <div class="form-group">
                                <input type="text" placeholder="Your Name" required>
                            </div>
                            <div class="form-group">
                                <input type="email" placeholder="Your Email" required>
                            </div>
                            <div class="form-group">
                                <textarea placeholder="Your Message" rows="4" required></textarea>
                            </div>
                            <button type="submit" class="btn-primary btn-block"><i class="fas fa-paper-plane"></i> Send Message</button>
                        </form>
                    </div>
                </div>
                <div class="map-section">
                    <h3><i class="fas fa-map"></i> Find Us Here</h3>
                    <div class="map-container">
                        <iframe src="https://maps.google.com/maps?q=Johannesburg,South+Africa&t=k&z=11&output=embed" width="100%" height="400" style="border:0;border-radius:10px;" allowfullscreen="" loading="lazy"></iframe>
                        <div class="map-overlay"><i class="fas fa-location-dot"></i><span>? View on Google Maps</span></div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- FOOTER -->
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-grid">
                <div class="footer-about">
                    <img src="${pageContext.request.contextPath}/images/logo/logo-white.png" alt="Smart LMS" width="60">
                    <h3>Smart LMS</h3>
                    <p>Empowering education through innovative technology.</p>
                    <div class="social-icons">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-youtube"></i></a>
                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="footer-links">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="${pageContext.request.contextPath}/public/index.jsp"><i class="fas fa-chevron-right"></i> Home</a></li>
                        <li><a href="#courses"><i class="fas fa-chevron-right"></i> Courses</a></li>
                        <li><a href="#about"><i class="fas fa-chevron-right"></i> About Us</a></li>
                        <li><a href="#contact"><i class="fas fa-chevron-right"></i> Contact</a></li>
                    </ul>
                </div>
                <div class="footer-contact">
                    <h4>Contact Info</h4>
                    <ul>
                        <li><i class="fas fa-map-marker-alt"></i> 123 Education Street, Johannesburg</li>
                        <li><i class="fas fa-phone"></i> +27 12 345 6789</li>
                        <li><i class="fas fa-envelope"></i> info@smartlms.com</li>
                    </ul>
                </div>
                <div class="footer-newsletter">
                    <h4>Newsletter</h4>
                    <p>Subscribe for updates.</p>
                    <form class="newsletter-form">
                        <input type="email" placeholder="Your Email" required>
                        <button type="submit"><i class="fas fa-paper-plane"></i></button>
                    </form>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2026 Smart Learning Management System. All rights reserved.</p>
            </div>
        </div>
    </footer>
</body>
</html>