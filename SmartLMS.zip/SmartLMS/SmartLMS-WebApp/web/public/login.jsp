<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart LMS - Login</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
    <link rel="icon" href="${pageContext.request.contextPath}/images/logo/favicon.ico">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body style="background-image: url('${pageContext.request.contextPath}/images/backgrounds/login-bg.jpg'); background-size: cover; background-position: center;">

    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-logo">
                <i class="fas fa-graduation-cap" style="font-size:1.8rem;color:#4a90d9;"></i>
                <span>Smart LMS</span>
            </div>
            <ul class="nav-menu">
                <li><a href="${pageContext.request.contextPath}/public/index.jsp"><i class="fas fa-home"></i> Home</a></li>
                <li><a href="${pageContext.request.contextPath}/public/index.jsp#courses"><i class="fas fa-book"></i> Courses</a></li>
                <li><a href="${pageContext.request.contextPath}/public/index.jsp#about"><i class="fas fa-info-circle"></i> About</a></li>
                <li><a href="${pageContext.request.contextPath}/public/index.jsp#contact"><i class="fas fa-envelope"></i> Contact</a></li>
                <li><a href="${pageContext.request.contextPath}/public/login.jsp" class="active btn-login"><i class="fas fa-sign-in-alt"></i> Login</a></li>
                <li><a href="${pageContext.request.contextPath}/public/register.jsp" class="btn-register"><i class="fas fa-user-plus"></i> Register</a></li>
            </ul>
        </div>
    </nav>

    <div class="auth-container">
        <div class="auth-box">
            <img src="${pageContext.request.contextPath}/images/logo/logo.png" alt="Smart LMS" width="120">
            <h2>Login to Smart LMS</h2>
            
            <% if (request.getAttribute("error") != null) { %>
                <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <%= request.getAttribute("error") %></div>
            <% } %>
            
            <% if (request.getParameter("registered") != null) { %>
                <div class="alert alert-success"><i class="fas fa-check-circle"></i> Registration successful! Please login.</div>
            <% } %>
            
            <form action="${pageContext.request.contextPath}/login" method="post">
                <div class="form-group">
                    <label><i class="fas fa-envelope"></i> Email Address</label>
                    <input type="email" name="email" class="form-control" placeholder="Enter your email" required>
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-lock"></i> Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block"><i class="fas fa-sign-in-alt"></i> Login</button>
            </form>
            
            <p style="margin-top:15px;">Don't have an account? <a href="${pageContext.request.contextPath}/public/register.jsp"><i class="fas fa-user-plus"></i> Get Started</a></p>
        </div>
    </div>

</body>
</html>