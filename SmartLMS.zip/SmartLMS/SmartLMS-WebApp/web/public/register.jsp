<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart LMS - Register</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
    <link rel="icon" href="${pageContext.request.contextPath}/images/logo/favicon.ico">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body style="background-image: url('${pageContext.request.contextPath}/images/backgrounds/register-bg.jpg'); background-size: cover; background-position: center;">

    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-logo">
                <i class="fas fa-graduation-cap" style="font-size:1.8rem;color:#4a90d9;"></i>
                <span>Smart LMS</span>
            </div>
            <ul class="nav-menu">
                <li><a href="${pageContext.request.contextPath}/public/index.jsp"><i class="fas fa-home"></i> Home</a></li>
                <li><a href="${pageContext.request.contextPath}/public/index.jsp#courses"><i class="fas fa-book"></i> Courses</a></li>
                <li><a href="${pageContext.request.contextPath}/public/index.jsp#about"><i class="fas fa-info-circle"></i> About</a></li>
                <li><a href="${pageContext.request.contextPath}/public/index.jsp#contact"><i class="fas fa-envelope"></i> Contact</a></li>
                <li><a href="${pageContext.request.contextPath}/public/login.jsp" class="btn-login"><i class="fas fa-sign-in-alt"></i> Login</a></li>
                <li><a href="${pageContext.request.contextPath}/public/register.jsp" class="active btn-register"><i class="fas fa-user-plus"></i> Register</a></li>
            </ul>
        </div>
    </nav>

    <div class="auth-container">
        <div class="auth-box">
            <img src="${pageContext.request.contextPath}/images/logo/logo.png" alt="Smart LMS" width="120">
            <h2>Create Account</h2>
            
            <% if (request.getAttribute("error") != null) { %>
                <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <%= request.getAttribute("error") %></div>
            <% } %>
            
            <form action="${pageContext.request.contextPath}/register" method="post">
                <div class="form-group">
                    <label><i class="fas fa-user"></i> Full Name</label>
                    <input type="text" name="fullName" class="form-control" placeholder="Enter your full name" required>
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-envelope"></i> Email Address</label>
                    <input type="email" name="email" class="form-control" placeholder="Enter your email" required>
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-lock"></i> Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Create password" required>
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-check-circle"></i> Confirm Password</label>
                    <input type="password" name="confirmPassword" class="form-control" placeholder="Confirm password" required>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block"><i class="fas fa-user-plus"></i> Register</button>
            </form>
            
            <p style="margin-top:15px;">Already have an account? <a href="${pageContext.request.contextPath}/public/login.jsp"><i class="fas fa-sign-in-alt"></i> Login</a></p>
        </div>
    </div>

</body>
</html>