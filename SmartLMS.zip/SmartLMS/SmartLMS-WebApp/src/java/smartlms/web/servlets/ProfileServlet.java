/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package smartlms.web.servlets;

import smartlms.learn.ejb.User;
import smartlms.learn.session.UserFacadeLocal;
import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

public class ProfileServlet extends HttpServlet {

    @EJB
    private UserFacadeLocal userFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect(request.getContextPath() + "/student/profile.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        String action = request.getParameter("action");

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/public/login.jsp");
            return;
        }

        if ("changePassword".equals(action)) {
            String currentPassword = request.getParameter("currentPassword");
            String newPassword = request.getParameter("newPassword");
            String confirmPassword = request.getParameter("confirmPassword");

            if (!user.getPassword().equals(currentPassword)) {
                request.setAttribute("error", "Current password is incorrect");
                request.getRequestDispatcher("/student/profile.jsp").forward(request, response);
                return;
            }

            if (!newPassword.equals(confirmPassword)) {
                request.setAttribute("error", "New passwords do not match");
                request.getRequestDispatcher("/student/profile.jsp").forward(request, response);
                return;
            }

            user.setPassword(newPassword);
            userFacade.edit(user);
            session.setAttribute("user", user);
            request.setAttribute("message", "Password updated successfully!");
            request.getRequestDispatcher("/student/profile.jsp").forward(request, response);
            return;
        }

        // Update profile
        String fullName = request.getParameter("fullName");
        String email = request.getParameter("email");
        String bio = request.getParameter("bio");

        if (fullName != null && !fullName.isEmpty()) {
            user.setFullName(fullName);
        }
        if (email != null && !email.isEmpty()) {
            user.setEmail(email);
        }
        if (bio != null) {
            user.setBio(bio);
        }

        userFacade.edit(user);
        session.setAttribute("user", user);
        session.setAttribute("fullName", user.getFullName());
        request.setAttribute("message", "Profile updated successfully!");
        request.getRequestDispatcher("/student/profile.jsp").forward(request, response);
    }
}