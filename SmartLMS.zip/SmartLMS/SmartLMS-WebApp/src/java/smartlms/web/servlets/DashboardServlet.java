package smartlms.web.servlets;

import smartlms.learn.ejb.User;
import smartlms.learn.ejb.Enrollment;
import smartlms.learn.session.EnrollmentFacadeLocal;
import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

public class DashboardServlet extends HttpServlet {

    @EJB
    private EnrollmentFacadeLocal enrollmentFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/public/login.jsp");
            return;
        }

        // Get enrollments
        List<Enrollment> enrollments = enrollmentFacade.findByStudent(user.getId());
        
        int enrolledCount = enrollments != null ? enrollments.size() : 0;
        int completedCount = 0;
        int totalProgress = 0;
        
        if (enrollments != null) {
            for (Enrollment e : enrollments) {
                if (e.isCompleted()) {
                    completedCount++;
                }
                totalProgress += e.getProgress();
            }
        }
        
        int avgProgress = enrolledCount > 0 ? totalProgress / enrolledCount : 0;
        int pendingAssignments = 3; // Replace with real data from AssignmentFacade

        // Set attributes for JSP
        request.setAttribute("enrollments", enrollments);
        request.setAttribute("enrolledCount", enrolledCount);
        request.setAttribute("completedCount", completedCount);
        request.setAttribute("avgProgress", avgProgress);
        request.setAttribute("pendingAssignments", pendingAssignments);
        
        request.getRequestDispatcher("/student/dashboard.jsp").forward(request, response);
    }
}