/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package smartlms.web.servlets;

import smartlms.learn.ejb.Enrollment;
import smartlms.learn.ejb.User;
import smartlms.learn.ejb.Course;
import smartlms.learn.session.EnrollmentFacadeLocal;
import smartlms.learn.session.CourseFacadeLocal;
import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

/**
 *
 * @author sfiso
 */
public class EnrollmentServlet extends HttpServlet {

    @EJB
    private EnrollmentFacadeLocal enrollmentFacade;
    
    @EJB
    private CourseFacadeLocal courseFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        Long studentId = user != null ? user.getId() : null;

        // Check if user is logged in
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/public/login.jsp");
            return;
        }

        if ("enroll".equals(action)) {
            Long courseId = Long.parseLong(request.getParameter("courseId"));
            
            // Check if already enrolled
            Enrollment existing = enrollmentFacade.findByStudentAndCourse(studentId, courseId);
            if (existing == null) {
                Enrollment enrollment = new Enrollment();
                enrollment.setStudent(user);
                enrollment.setCourse(courseFacade.find(courseId));
                enrollmentFacade.create(enrollment);
                
                request.setAttribute("message", "Successfully enrolled in the course!");
                request.setAttribute("messageType", "success");
            } else {
                request.setAttribute("message", "You are already enrolled in this course!");
                request.setAttribute("messageType", "info");
            }
            
            // Forward to course details page
            request.setAttribute("courseId", courseId);
            request.getRequestDispatcher("/student/course-details.jsp").forward(request, response);
            return;
        }

        if ("unenroll".equals(action)) {
            Long enrollmentId = Long.parseLong(request.getParameter("id"));
            Enrollment enrollment = enrollmentFacade.find(enrollmentId);
            if (enrollment != null && enrollment.getStudent().getId().equals(studentId)) {
                enrollmentFacade.remove(enrollment);
                request.setAttribute("message", "You have been unenrolled from the course.");
                request.setAttribute("messageType", "warning");
            }
            request.getRequestDispatcher("/student/my-courses.jsp").forward(request, response);
            return;
        }

        if ("my-courses".equals(action)) {
            // Show student's enrolled courses
            List<Enrollment> enrollments = enrollmentFacade.findByStudent(studentId);
            request.setAttribute("enrollments", enrollments);
            request.getRequestDispatcher("/student/my-courses.jsp").forward(request, response);
            return;
        }

        // Default: show all courses with enrollment status
        List<Course> courses = courseFacade.findAllActive();
        request.setAttribute("courses", courses);
        request.setAttribute("studentId", studentId);
        request.getRequestDispatcher("/student/courses.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        Long studentId = user != null ? user.getId() : null;

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/public/login.jsp");
            return;
        }

        if ("updateProgress".equals(action)) {
            Long enrollmentId = Long.parseLong(request.getParameter("enrollmentId"));
            Integer progress = Integer.parseInt(request.getParameter("progress"));
            
            // Validate progress
            if (progress < 0) progress = 0;
            if (progress > 100) progress = 100;
            
            enrollmentFacade.updateProgress(enrollmentId, progress);
            
            // If progress is 100, mark as completed
            if (progress == 100) {
                enrollmentFacade.markCompleted(enrollmentId);
            }
            
            response.sendRedirect(request.getContextPath() + "/student/my-courses.jsp");
            return;
        }

        // Default redirect
        response.sendRedirect(request.getContextPath() + "/student/dashboard.jsp");
    }
}