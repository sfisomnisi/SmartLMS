/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package smartlms.web.servlets;

import smartlms.learn.ejb.Submission;
import smartlms.learn.session.SubmissionFacadeLocal;
import smartlms.learn.session.AssignmentFacadeLocal;
import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

/**
 *
 * @author sfiso
 */
public class SubmissionServlet extends HttpServlet {

    @EJB
    private SubmissionFacadeLocal submissionFacade;
    
    @EJB
    private AssignmentFacadeLocal assignmentFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        HttpSession session = request.getSession();
        Long studentId = (Long) session.getAttribute("userId");

        if ("view".equals(action)) {
            Long submissionId = Long.parseLong(request.getParameter("id"));
            Submission submission = submissionFacade.find(submissionId);
            request.setAttribute("submission", submission);
            request.getRequestDispatcher("/student/submission-details.jsp").forward(request, response);
            return;
        }

        if ("grade".equals(action)) {
            Long assignmentId = Long.parseLong(request.getParameter("assignmentId"));
            List<Submission> submissions = submissionFacade.findByAssignment(assignmentId);
            request.setAttribute("submissions", submissions);
            request.setAttribute("assignmentId", assignmentId);
            request.getRequestDispatcher("/instructor/grade-submissions.jsp").forward(request, response);
            return;
        }

        // View my submissions
        List<Submission> submissions = submissionFacade.findByStudent(studentId);
        request.setAttribute("submissions", submissions);
        request.getRequestDispatcher("/student/my-submissions.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        HttpSession session = request.getSession();
        Long studentId = (Long) session.getAttribute("userId");

        if ("submit".equals(action)) {
            Long assignmentId = Long.parseLong(request.getParameter("assignmentId"));
            String submissionText = request.getParameter("submissionText");

            // Check if already submitted
            Submission existing = submissionFacade.findByAssignmentAndStudent(assignmentId, studentId);
            if (existing == null) {
                Submission submission = new Submission();
                submission.setAssignment(assignmentFacade.find(assignmentId));
                submission.setStudent((smartlms.learn.ejb.User) session.getAttribute("user"));
                submission.setSubmissionText(submissionText);
                submissionFacade.create(submission);
            } else {
                // Update existing submission
                existing.setSubmissionText(submissionText);
                existing.setStatus("PENDING");
                submissionFacade.edit(existing);
            }

            response.sendRedirect(request.getContextPath() + "/student/assignments.jsp?courseId=" + 
                request.getParameter("courseId"));
            return;
        }

        if ("grade".equals(action)) {
            Long submissionId = Long.parseLong(request.getParameter("submissionId"));
            Integer grade = Integer.parseInt(request.getParameter("grade"));
            String feedback = request.getParameter("feedback");
            Long gradedBy = (Long) session.getAttribute("userId");

            submissionFacade.gradeSubmission(submissionId, grade, feedback, gradedBy);
            response.sendRedirect(request.getContextPath() + "/instructor/grade-submissions.jsp?assignmentId=" + 
                request.getParameter("assignmentId"));
            return;
        }

        response.sendRedirect(request.getContextPath() + "/student/dashboard.jsp");
    }
}