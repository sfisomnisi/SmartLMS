package smartlms.web.servlets;

import smartlms.learn.ejb.Course;
import smartlms.learn.ejb.User;
import smartlms.learn.ejb.Enrollment;
import smartlms.learn.session.CourseFacadeLocal;
import smartlms.learn.session.EnrollmentFacadeLocal;
import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CourseServlet extends HttpServlet {

    @EJB
    private CourseFacadeLocal courseFacade;
    
    @EJB
    private EnrollmentFacadeLocal enrollmentFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        String action = request.getParameter("action");

        // Check if user is logged in
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/public/login.jsp");
            return;
        }

        // Handle different actions
        if (action != null) {
            if ("view".equals(action)) {
                Long courseId = Long.parseLong(request.getParameter("id"));
                Course course = courseFacade.find(courseId);
                request.setAttribute("course", course);
                request.getRequestDispatcher("/student/course-details.jsp").forward(request, response);
                return;
            }

            if ("edit".equals(action)) {
                Long courseId = Long.parseLong(request.getParameter("id"));
                Course course = courseFacade.find(courseId);
                request.setAttribute("course", course);
                request.getRequestDispatcher("/instructor/edit-course.jsp").forward(request, response);
                return;
            }

            if ("delete".equals(action)) {
                Long courseId = Long.parseLong(request.getParameter("id"));
                Course course = courseFacade.find(courseId);
                if (course != null) {
                    course.setActive(false);
                    courseFacade.edit(course);
                }
                response.sendRedirect(request.getContextPath() + "/instructor/manage-courses.jsp");
                return;
            }
        }

        // Get all active courses
        List<Course> courses = courseFacade.findAllActive();
        request.setAttribute("courses", courses);
        
        // Get enrollment status for each course
        Map<Long, Boolean> enrolledMap = new HashMap<>();
        if (courses != null && !courses.isEmpty()) {
            for (Course course : courses) {
                boolean isEnrolled = enrollmentFacade.isEnrolled(user.getId(), course.getId());
                enrolledMap.put(course.getId(), isEnrolled);
            }
        }
        request.setAttribute("enrolledMap", enrolledMap);

        // For instructor, show their courses
        String role = (String) session.getAttribute("role");
        if ("INSTRUCTOR".equals(role) || "ADMIN".equals(role)) {
            Long instructorId = (Long) session.getAttribute("userId");
            List<Course> instructorCourses = courseFacade.findByInstructor(instructorId);
            request.setAttribute("instructorCourses", instructorCourses);
            request.getRequestDispatcher("/instructor/manage-courses.jsp").forward(request, response);
        } else {
            request.getRequestDispatcher("/student/courses.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        // Check if user is logged in
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/public/login.jsp");
            return;
        }

        if ("create".equals(action)) {
            String title = request.getParameter("title");
            String description = request.getParameter("description");
            String category = request.getParameter("category");
            String level = request.getParameter("level");
            Double price = Double.parseDouble(request.getParameter("price"));

            User instructor = new User();
            instructor.setId((Long) session.getAttribute("userId"));

            Course course = new Course();
            course.setTitle(title);
            course.setDescription(description);
            course.setCategory(category);
            course.setLevel(level);
            course.setPrice(price);
            course.setInstructor(instructor);

            courseFacade.create(course);
            response.sendRedirect(request.getContextPath() + "/instructor/manage-courses.jsp");
            return;
        }

        if ("update".equals(action)) {
            Long courseId = Long.parseLong(request.getParameter("id"));
            Course course = courseFacade.find(courseId);
            if (course != null) {
                course.setTitle(request.getParameter("title"));
                course.setDescription(request.getParameter("description"));
                course.setCategory(request.getParameter("category"));
                course.setLevel(request.getParameter("level"));
                course.setPrice(Double.parseDouble(request.getParameter("price")));
                courseFacade.edit(course);
            }
            response.sendRedirect(request.getContextPath() + "/instructor/manage-courses.jsp");
            return;
        }

        // Search courses
        String search = request.getParameter("search");
        if (search != null && !search.isEmpty()) {
            List<Course> courses = courseFacade.findAllActive();
            courses.removeIf(c -> !c.getTitle().toLowerCase().contains(search.toLowerCase()));
            request.setAttribute("courses", courses);
        }

        request.getRequestDispatcher("/student/courses.jsp").forward(request, response);
    }
}