package smartlms.web.servlets;

import smartlms.learn.ejb.Course;
import smartlms.learn.ejb.Enrollment;
import smartlms.learn.ejb.User;
import smartlms.learn.ejb.Assignment;
import smartlms.learn.ejb.Quiz;
import smartlms.learn.session.CourseFacadeLocal;
import smartlms.learn.session.EnrollmentFacadeLocal;
import smartlms.learn.session.AssignmentFacadeLocal;
import smartlms.learn.session.QuizFacadeLocal;
import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

public class CourseDetailsServlet extends HttpServlet {

    @EJB
    private CourseFacadeLocal courseFacade;
    
    @EJB
    private EnrollmentFacadeLocal enrollmentFacade;
    
    @EJB
    private AssignmentFacadeLocal assignmentFacade;
    
    @EJB
    private QuizFacadeLocal quizFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/public/login.jsp");
            return;
        }

        String courseIdParam = request.getParameter("courseId");
        if (courseIdParam == null) {
            response.sendRedirect(request.getContextPath() + "/student/dashboard.jsp");
            return;
        }

        Long courseId = Long.parseLong(courseIdParam);
        Course course = courseFacade.find(courseId);
        Enrollment enrollment = enrollmentFacade.findByStudentAndCourse(user.getId(), courseId);
        
        if (enrollment == null) {
            response.sendRedirect(request.getContextPath() + "/student/courses.jsp");
            return;
        }

        List<Assignment> assignments = assignmentFacade.findByCourse(courseId);
        List<Quiz> quizzes = quizFacade.findByCourse(courseId);

        request.setAttribute("course", course);
        request.setAttribute("enrollment", enrollment);
        request.setAttribute("assignments", assignments);
        request.setAttribute("quizzes", quizzes);
        request.getRequestDispatcher("/student/course-details.jsp").forward(request, response);
    }
}