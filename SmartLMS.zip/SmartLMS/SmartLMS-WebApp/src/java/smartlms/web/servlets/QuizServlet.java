package smartlms.web.servlets;

import smartlms.learn.ejb.User;
import smartlms.learn.ejb.Quiz;
import smartlms.learn.ejb.QuizQuestion;
import smartlms.learn.ejb.QuizAttempt;
import smartlms.learn.session.QuizFacadeLocal;
import smartlms.learn.session.QuizQuestionFacadeLocal;
import smartlms.learn.session.QuizAttemptFacadeLocal;
import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

public class QuizServlet extends HttpServlet {

    @EJB
    private QuizFacadeLocal quizFacade;
    
    @EJB
    private QuizQuestionFacadeLocal questionFacade;
    
    @EJB
    private QuizAttemptFacadeLocal attemptFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/public/login.jsp");
            return;
        }

        String action = request.getParameter("action");
        Long quizId = Long.parseLong(request.getParameter("quizId"));

        if ("take".equals(action)) {
            Quiz quiz = quizFacade.find(quizId);
            List<QuizQuestion> questions = questionFacade.findByQuiz(quizId);
            
            request.setAttribute("quiz", quiz);
            request.setAttribute("questions", questions);
            request.getRequestDispatcher("/student/take-quiz.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/public/login.jsp");
            return;
        }

        Long quizId = Long.parseLong(request.getParameter("quizId"));
        List<QuizQuestion> questions = questionFacade.findByQuiz(quizId);
        
        int score = 0;
        for (QuizQuestion question : questions) {
            String userAnswer = request.getParameter("question_" + question.getId());
            if (userAnswer != null && userAnswer.equals(question.getCorrectAnswer())) {
                score++;
            }
        }
        
        int total = questions.size();
        boolean passed = score >= (total * 0.5); // 50% to pass
        
        // Save attempt
        QuizAttempt attempt = new QuizAttempt();
        attempt.setStudent(user);
        attempt.setQuiz(quizFacade.find(quizId));
        attempt.setScore(score);
        attempt.setPassed(passed);
        attemptFacade.create(attempt);
        
        request.setAttribute("score", score);
        request.setAttribute("total", total);
        request.setAttribute("passed", passed);
        request.getRequestDispatcher("/student/quiz-result.jsp").forward(request, response);
    }
}