package smartlms.web.servlets;

import smartlms.learn.ejb.User;
import smartlms.learn.session.EnrollmentFacadeLocal;
import smartlms.learn.session.SubmissionFacadeLocal;
import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

public class GradeServlet extends HttpServlet {

    @EJB
    private EnrollmentFacadeLocal enrollmentFacade;
    
    @EJB
    private SubmissionFacadeLocal submissionFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/public/login.jsp");
            return;
        }
        
        // Get grades data
        request.setAttribute("enrollments", enrollmentFacade.findByStudent(user.getId()));
        request.setAttribute("submissions", submissionFacade.findByStudent(user.getId()));
        request.getRequestDispatcher("/student/grades.jsp").forward(request, response);
    }
}