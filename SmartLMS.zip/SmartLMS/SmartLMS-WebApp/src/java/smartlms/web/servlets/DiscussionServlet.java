/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package smartlms.web.servlets;

import smartlms.learn.ejb.Discussion;
import smartlms.learn.ejb.DiscussionReply;
import smartlms.learn.session.DiscussionFacadeLocal;
import smartlms.learn.session.DiscussionReplyFacadeLocal;
import smartlms.learn.session.CourseFacadeLocal;
import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

/**
 *
 * @author sfiso
 */
public class DiscussionServlet extends HttpServlet {

    @EJB
    private DiscussionFacadeLocal discussionFacade;
    
    @EJB
    private DiscussionReplyFacadeLocal replyFacade;
    
    @EJB
    private CourseFacadeLocal courseFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        Long courseId = request.getParameter("courseId") != null ? 
            Long.parseLong(request.getParameter("courseId")) : null;

        if (action != null) {
            if ("view".equals(action)) {
                Long discussionId = Long.parseLong(request.getParameter("id"));
                Discussion discussion = discussionFacade.find(discussionId);
                List<DiscussionReply> replies = replyFacade.findByDiscussion(discussionId);
                request.setAttribute("discussion", discussion);
                request.setAttribute("replies", replies);
                request.getRequestDispatcher("/student/discussion-details.jsp").forward(request, response);
                return;
            }

            if ("delete".equals(action)) {
                Long discussionId = Long.parseLong(request.getParameter("id"));
                Discussion discussion = discussionFacade.find(discussionId);
                if (discussion != null) {
                    discussionFacade.remove(discussion);
                }
                response.sendRedirect(request.getContextPath() + "/student/course-details.jsp?id=" + courseId);
                return;
            }
        }

        // List discussions for a course
        if (courseId != null) {
            List<Discussion> discussions = discussionFacade.findByCourse(courseId);
            List<Discussion> announcements = discussionFacade.findAnnouncements(courseId);
            request.setAttribute("discussions", discussions);
            request.setAttribute("announcements", announcements);
            request.setAttribute("courseId", courseId);
            request.getRequestDispatcher("/student/course-discussions.jsp").forward(request, response);
        } else {
            response.sendRedirect(request.getContextPath() + "/student/dashboard.jsp");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        HttpSession session = request.getSession();

        if ("create".equals(action)) {
            Long courseId = Long.parseLong(request.getParameter("courseId"));
            String title = request.getParameter("title");
            String content = request.getParameter("content");
            boolean isAnnouncement = "true".equals(request.getParameter("isAnnouncement"));

            Discussion discussion = new Discussion();
            discussion.setTitle(title);
            discussion.setContent(content);
            discussion.setCourse(courseFacade.find(courseId));
            discussion.setAuthor((smartlms.learn.ejb.User) session.getAttribute("user"));
            discussion.setAnnouncement(isAnnouncement);
            discussionFacade.create(discussion);

            response.sendRedirect(request.getContextPath() + "/student/course-details.jsp?id=" + courseId);
            return;
        }

        if ("reply".equals(action)) {
            Long discussionId = Long.parseLong(request.getParameter("discussionId"));
            String content = request.getParameter("content");

            DiscussionReply reply = new DiscussionReply();
            reply.setContent(content);
            reply.setDiscussion(discussionFacade.find(discussionId));
            reply.setAuthor((smartlms.learn.ejb.User) session.getAttribute("user"));
            replyFacade.create(reply);

            response.sendRedirect(request.getContextPath() + "/student/discussion-details.jsp?id=" + discussionId);
            return;
        }

        response.sendRedirect(request.getContextPath() + "/student/dashboard.jsp");
    }
}