/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package smartlms.web.servlets;

import smartlms.learn.ejb.Assignment;
import smartlms.learn.session.AssignmentFacadeLocal;
import smartlms.learn.session.CourseFacadeLocal;
import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 *
 * @author sfiso
 */
public class AssignmentServlet extends HttpServlet {

    @EJB
    private AssignmentFacadeLocal assignmentFacade;
    
    @EJB
    private CourseFacadeLocal courseFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        Long courseId = request.getParameter("courseId") != null ? 
            Long.parseLong(request.getParameter("courseId")) : null;

        if ("view".equals(action)) {
            Long assignmentId = Long.parseLong(request.getParameter("id"));
            Assignment assignment = assignmentFacade.find(assignmentId);
            request.setAttribute("assignment", assignment);
            request.getRequestDispatcher("/student/assignment-details.jsp").forward(request, response);
            return;
        }

        if ("edit".equals(action)) {
            Long assignmentId = Long.parseLong(request.getParameter("id"));
            Assignment assignment = assignmentFacade.find(assignmentId);
            request.setAttribute("assignment", assignment);
            request.setAttribute("courseId", assignment.getCourse().getId());
            request.getRequestDispatcher("/instructor/edit-assignment.jsp").forward(request, response);
            return;
        }

        if ("delete".equals(action)) {
            Long assignmentId = Long.parseLong(request.getParameter("id"));
            Assignment assignment = assignmentFacade.find(assignmentId);
            if (assignment != null) {
                assignment.setActive(false);
                assignmentFacade.edit(assignment);
            }
            response.sendRedirect(request.getContextPath() + "/instructor/manage-courses.jsp");
            return;
        }

        // List assignments for a course
        if (courseId != null) {
            List<Assignment> assignments = assignmentFacade.findByCourse(courseId);
            request.setAttribute("assignments", assignments);
            request.setAttribute("courseId", courseId);
            request.getRequestDispatcher("/student/assignments.jsp").forward(request, response);
        } else {
            response.sendRedirect(request.getContextPath() + "/student/dashboard.jsp");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if ("create".equals(action)) {
            Long courseId = Long.parseLong(request.getParameter("courseId"));
            String title = request.getParameter("title");
            String description = request.getParameter("description");
            String dueDateStr = request.getParameter("dueDate");
            Integer maxScore = Integer.parseInt(request.getParameter("maxScore"));

            Assignment assignment = new Assignment();
            assignment.setTitle(title);
            assignment.setDescription(description);
            assignment.setCourse(courseFacade.find(courseId));
            assignment.setMaxScore(maxScore);

            // Parse due date
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                Date dueDate = sdf.parse(dueDateStr);
                assignment.setDueDate(dueDate);
            } catch (Exception e) {
                // Default due date 7 days from now
                assignment.setDueDate(new Date(System.currentTimeMillis() + 7 * 24 * 60 * 60 * 1000));
            }

            assignmentFacade.create(assignment);
            response.sendRedirect(request.getContextPath() + "/instructor/manage-courses.jsp");
            return;
        }

        if ("update".equals(action)) {
            Long assignmentId = Long.parseLong(request.getParameter("id"));
            Assignment assignment = assignmentFacade.find(assignmentId);
            if (assignment != null) {
                assignment.setTitle(request.getParameter("title"));
                assignment.setDescription(request.getParameter("description"));
                assignment.setMaxScore(Integer.parseInt(request.getParameter("maxScore")));
                // Parse due date
                try {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    Date dueDate = sdf.parse(request.getParameter("dueDate"));
                    assignment.setDueDate(dueDate);
                } catch (Exception e) {
                    // Keep existing due date
                }
                assignmentFacade.edit(assignment);
            }
            response.sendRedirect(request.getContextPath() + "/instructor/manage-courses.jsp");
            return;
        }

        response.sendRedirect(request.getContextPath() + "/student/dashboard.jsp");
    }
}