/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package smartlms.web.filters;

import java.io.IOException;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 *
 * @author sfiso
 */
public class AuthFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        HttpSession session = req.getSession(false);

        // Check if user is logged in
        boolean isLoggedIn = (session != null && session.getAttribute("user") != null);

        // Get the requested path
        String path = req.getRequestURI().substring(req.getContextPath().length());

        // Allow public pages
        if (path.startsWith("/public/") || path.equals("/public/") || path.equals("/")) {
            chain.doFilter(request, response);
            return;
        }

        // Check if trying to access static resources
        if (path.startsWith("/css/") || path.startsWith("/js/") || path.startsWith("/images/")) {
            chain.doFilter(request, response);
            return;
        }

        // If not logged in, redirect to login
        if (!isLoggedIn) {
            res.sendRedirect(req.getContextPath() + "/public/login.jsp");
            return;
        }

        // Check role-based access
        String role = (String) session.getAttribute("role");
        
        if (path.startsWith("/instructor/") && !"INSTRUCTOR".equals(role) && !"ADMIN".equals(role)) {
            res.sendRedirect(req.getContextPath() + "/student/dashboard.jsp");
            return;
        }
        
        if (path.startsWith("/admin/") && !"ADMIN".equals(role)) {
            res.sendRedirect(req.getContextPath() + "/student/dashboard.jsp");
            return;
        }

        // Allow access
        chain.doFilter(request, response);
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {}

    @Override
    public void destroy() {}
}